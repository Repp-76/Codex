import sys

from codex.startup import main

sys.exit(main(sys.argv[1:]))
