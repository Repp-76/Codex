from codex.ai.base import Provider, ProviderError


class OpenAICompatible(Provider):
    base_url = ""
    extra_headers = {}
    max_tokens = None

    def chat(self, messages, system):
        payload = {
            "model": self.model,
            "messages": [{"role": "system", "content": system}]
            + [{"role": m.role, "content": m.content} for m in messages],
        }
        if self.max_tokens:
            payload["max_tokens"] = self.max_tokens
        headers = {"Authorization": f"Bearer {self.api_key}", **self.extra_headers}
        data = self._post(f"{self.base_url}/chat/completions", headers, payload)
        try:
            content = data["choices"][0]["message"]["content"]
        except (KeyError, IndexError, TypeError):
            raise ProviderError("malformed") from None
        if isinstance(content, list):
            content = "".join(p.get("text", "") for p in content if isinstance(p, dict))
        if not isinstance(content, str) or not content.strip():
            raise ProviderError("malformed", "empty response")
        return content


class OpenAI(OpenAICompatible):
    name = "openai"
    label = "OpenAI"
    env_key = "OPENAI_API_KEY"
    default_model = "gpt-4.1"
    base_url = "https://api.openai.com/v1"


class DeepSeek(OpenAICompatible):
    name = "deepseek"
    label = "DeepSeek"
    env_key = "DEEPSEEK_API_KEY"
    default_model = "deepseek-chat"
    base_url = "https://api.deepseek.com"
    max_tokens = 8192


class OpenRouter(OpenAICompatible):
    name = "openrouter"
    label = "OpenRouter"
    env_key = "OPENROUTER_API_KEY"
    default_model = "anthropic/claude-sonnet-4.5"
    base_url = "https://openrouter.ai/api/v1"
    extra_headers = {"X-Title": "CODEX"}
