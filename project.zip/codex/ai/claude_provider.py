from codex.ai.base import Provider, ProviderError


class Claude(Provider):
    name = "anthropic"
    label = "Claude"
    env_key = "ANTHROPIC_API_KEY"
    default_model = "claude-sonnet-5-5"
    url = "https://api.anthropic.com/v1/messages"

    def chat(self, messages, system):
        payload = {
            "model": self.model,
            "max_tokens": 8192,
            "system": system,
            "messages": [{"role": m.role, "content": m.content} for m in messages],
        }
        headers = {"x-api-key": self.api_key, "anthropic-version": "2023-06-01"}
        data = self._post(self.url, headers, payload)
        blocks = data.get("content")
        if not isinstance(blocks, list):
            raise ProviderError("malformed")
        text = "".join(b.get("text", "") for b in blocks if isinstance(b, dict) and b.get("type") == "text")
        if not text.strip():
            raise ProviderError("malformed", "empty response")
        return text
