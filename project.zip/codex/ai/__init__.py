from codex.ai.base import Message, Provider, ProviderError
from codex.ai.claude_provider import Claude
from codex.ai.gemini_provider import Gemini
from codex.ai.openai_compat import DeepSeek, OpenAI, OpenRouter

PROVIDERS = {
    "openai": OpenAI,
    "anthropic": Claude,
    "gemini": Gemini,
    "deepseek": DeepSeek,
    "openrouter": OpenRouter,
}
ALIASES = {"claude": "anthropic", "google": "gemini"}

__all__ = ["Message", "Provider", "ProviderError", "PROVIDERS", "ALIASES", "resolve_name", "build"]


def resolve_name(name):
    name = name.strip().lower()
    name = ALIASES.get(name, name)
    return name if name in PROVIDERS else None


def build(name, settings, http=None):
    cls = PROVIDERS[name]
    kwargs = {"http": http} if http else {}
    return cls(settings.api_keys.get(name, ""), settings.models.get(name, ""), **kwargs)
