from codex.ai.base import Provider, ProviderError


class Gemini(Provider):
    name = "gemini"
    label = "Gemini"
    env_key = "GEMINI_API_KEY"
    default_model = "gemini-2.5-pro"
    base_url = "https://generativelanguage.googleapis.com/v1beta/models"

    def chat(self, messages, system):
        payload = {
            "systemInstruction": {"parts": [{"text": system}]},
            "contents": [
                {"role": "model" if m.role == "assistant" else "user", "parts": [{"text": m.content}]}
                for m in messages
            ],
        }
        url = f"{self.base_url}/{self.model}:generateContent"
        data = self._post(url, {"x-goog-api-key": self.api_key}, payload)
        block = (data.get("promptFeedback") or {}).get("blockReason")
        if block:
            raise ProviderError("invalid_request", f"blocked: {block}")
        try:
            parts = data["candidates"][0]["content"]["parts"]
            text = "".join(p.get("text", "") for p in parts)
        except (KeyError, IndexError, TypeError):
            raise ProviderError("malformed") from None
        if not text.strip():
            raise ProviderError("malformed", "empty response")
        return text
