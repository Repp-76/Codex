import json
from dataclasses import dataclass

from codex.http import json_headers, request
from codex.security import redact

MESSAGES = {
    "auth": "The API key was rejected. It may be invalid, expired or lack access.",
    "quota": "The quota or billing limit for this API key has been reached.",
    "rate_limit": "Rate limit reached. Wait a moment and try again.",
    "invalid_model": "The model name was not accepted. Check it with /model.",
    "context_limit": "The conversation is too large for this model. Start fresh with /new.",
    "invalid_request": "The provider rejected the request.",
    "outage": "The provider is unavailable right now.",
    "timeout": "The request timed out.",
    "dns": "DNS lookup failed. Check your internet connection.",
    "connection": "Could not connect to the provider. Check your internet connection.",
    "malformed": "The provider returned a response CODEX could not understand.",
}


class ProviderError(Exception):
    def __init__(self, kind, detail=""):
        self.kind = kind
        text = MESSAGES.get(kind, "Provider error.")
        detail = redact(detail or "")[:300].strip()
        if detail:
            text = f"{text} ({detail})"
        super().__init__(text)


@dataclass
class Message:
    role: str
    content: str


def _error_text(data):
    if isinstance(data, dict):
        err = data.get("error")
        if isinstance(err, dict):
            return str(err.get("message") or err.get("status") or "")
        if isinstance(err, str):
            return err
        if isinstance(data.get("message"), str):
            return data["message"]
    return ""


def classify(status, data, raw=""):
    text = _error_text(data) or raw[:200]
    low = text.lower()
    if status in (401, 403):
        return ProviderError("auth", text)
    if status == 402 or "quota" in low or "insufficient" in low or "billing" in low:
        return ProviderError("quota", text)
    if status == 429:
        return ProviderError("rate_limit", text)
    if status == 404 or ("model" in low and ("not found" in low or "does not exist" in low or "invalid" in low)):
        return ProviderError("invalid_model", text)
    if "context" in low or "too long" in low or "maximum" in low and "token" in low:
        return ProviderError("context_limit", text)
    if status >= 500:
        return ProviderError("outage", f"HTTP {status}")
    return ProviderError("invalid_request", text or f"HTTP {status}")


class Provider:
    name = ""
    label = ""
    env_key = ""
    default_model = ""
    timeout = 180

    def __init__(self, api_key="", model="", http=request):
        self.api_key = api_key
        self.model = model or self.default_model
        self.http = http

    @property
    def configured(self):
        return bool(self.api_key)

    def chat(self, messages, system):
        raise NotImplementedError

    def _post(self, url, headers, payload):
        resp = self.http("POST", url, json_headers(headers), json.dumps(payload).encode("utf-8"), self.timeout)
        if resp.error:
            raise ProviderError(resp.error)
        data = resp.json()
        if not 200 <= resp.status < 300:
            raise classify(resp.status, data, resp.body.decode("utf-8", "ignore"))
        if not isinstance(data, dict):
            raise ProviderError("malformed")
        if "error" in data and not any(k in data for k in ("choices", "content", "candidates")):
            code = data["error"].get("code") if isinstance(data["error"], dict) else None
            raise classify(code if isinstance(code, int) else 400, data)
        return data
