import re
from dataclasses import dataclass, field

from codex.files.workspace import WorkspaceError
from codex.security import PathError
from codex.telegram.events import FileCreatedEvent, FileModifiedEvent, ProjectCreatedEvent

SYSTEM_PROMPT = """You are CODEX, an expert terminal coding assistant built by Repp76.

How to work:
- Understand the request before writing code. Ask one short question only if it is truly ambiguous.
- Existing project files are shown below. Read them first, preserve working behaviour, change only what the task needs, and fix root causes rather than symptoms.
- Deliver complete, runnable implementations. No placeholders, TODO stubs or fake functionality.
- Check imports, paths, dependencies, edge cases and security. Never hard-code secrets; read them from environment variables.
- For projects, create one coherent set of files that work together.

Delivering files:
Write every file you create or change in exactly this form, with the complete file content:
<file path="relative/path/name.ext">
...complete content...
</file>
Paths are relative to the workspace. Do not wrap file content in markdown fences. Never write real secrets or a real .env; use .env.example. Keep prose outside file blocks short.

Reply in the language the user writes in."""

FILE_BLOCK = re.compile(r'<file\s+path="([^"]+)"\s*>\n?(.*?)\n?</file>', re.S)
CONTEXT_BUDGET = 60_000


@dataclass
class Change:
    rel: str
    created: bool
    lines: int
    path: object


@dataclass
class AgentResult:
    text: str
    changes: list = field(default_factory=list)
    skipped: list = field(default_factory=list)
    events: list = field(default_factory=list)


def _strip_fence(content):
    lines = content.strip("\n").split("\n")
    if len(lines) >= 2 and lines[0].startswith("```") and lines[-1].strip() == "```":
        return "\n".join(lines[1:-1])
    return content


class Agent:
    def __init__(self, workspace, conversation):
        self.workspace = workspace
        self.conversation = conversation
        self.focus = []

    def _context(self, prompt):
        files = self.workspace.files()
        tree = "\n".join(self.workspace.rel(f) for f in files) or "(empty)"
        wanted = list(self.focus)
        for f in files:
            rel = self.workspace.rel(f)
            if rel in wanted:
                continue
            pattern = r"(?<![\w./-])" + re.escape(rel) + r"(?![\w])"
            if re.search(pattern, prompt) or re.search(r"(?<![\w./-])" + re.escape(f.name) + r"(?![\w])", prompt):
                wanted.append(rel)
        blocks, used = [], 0
        for rel in wanted:
            try:
                text = self.workspace.read(rel)
            except (WorkspaceError, PathError):
                continue
            if used + len(text) > CONTEXT_BUDGET:
                continue
            used += len(text)
            blocks.append(f'<file path="{rel}">\n{text}\n</file>')
        context = f"\nWorkspace: {self.workspace.root.name}\nFiles:\n{tree}\n"
        if blocks:
            context += "\nCurrent contents of relevant files:\n" + "\n".join(blocks) + "\n"
        return SYSTEM_PROMPT + "\n" + context

    def run(self, prompt, provider):
        self.conversation.add("user", prompt)
        try:
            reply = provider.chat(self.conversation.messages(), self._context(prompt))
        except Exception:
            self.conversation.pop()
            raise
        self.conversation.add("assistant", reply)
        return self._apply(reply)

    def _apply(self, reply):
        result = AgentResult(text=FILE_BLOCK.sub("", reply).strip())
        self.workspace.checkpoint()
        for rel, content in FILE_BLOCK.findall(reply):
            content = _strip_fence(content)
            try:
                written = self.workspace.write(rel.strip(), content)
            except (WorkspaceError, PathError) as exc:
                result.skipped.append((rel, str(exc)))
                continue
            result.changes.append(Change(written.rel, written.created, content.count("\n") + 1, written.path))
        result.events = self._events(result.changes)
        return result

    def _events(self, changes):
        if not changes:
            return []
        if len(changes) == 1:
            c = changes[0]
            return [(FileCreatedEvent if c.created else FileModifiedEvent)(c.path)]
        tops = {c.rel.split("/")[0] for c in changes if "/" in c.rel}
        name = tops.pop() if len(tops) == 1 and all("/" in c.rel for c in changes) else self.workspace.root.name
        return [ProjectCreatedEvent(self.workspace.root, [c.path for c in changes], name)]
