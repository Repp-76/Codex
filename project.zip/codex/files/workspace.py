import os
import shutil
import time
from dataclasses import dataclass
from pathlib import Path

from codex.security import PROTECTED_DIRS, protected_reason, resolve_in

MAX_READ = 1_000_000


class WorkspaceError(Exception):
    pass


@dataclass
class WriteResult:
    path: Path
    rel: str
    created: bool


class Workspace:
    def __init__(self, root):
        self.set_root(root)

    def set_root(self, root):
        root = Path(root).expanduser()
        root.mkdir(parents=True, exist_ok=True)
        self.root = root.resolve()
        self._undo = []
        self._batch = 0

    def resolve(self, target):
        return resolve_in(self.root, target)

    def rel(self, path):
        return Path(path).resolve().relative_to(self.root).as_posix()

    def files(self, limit=300):
        found = []
        for base, dirs, names in os.walk(self.root):
            dirs[:] = sorted(d for d in dirs if d not in PROTECTED_DIRS)
            for name in sorted(names):
                path = Path(base) / name
                rel = path.relative_to(self.root)
                if path.is_symlink() or protected_reason(rel):
                    continue
                found.append(path)
                if len(found) >= limit:
                    return found
        return found

    def read(self, target):
        path = self.resolve(target)
        rel = path.relative_to(self.root)
        if protected_reason(rel):
            raise WorkspaceError("That file is protected and cannot be read by CODEX.")
        if not path.is_file():
            raise WorkspaceError("File not found.")
        if path.stat().st_size > MAX_READ:
            raise WorkspaceError("File is too large to open.")
        try:
            return path.read_text(encoding="utf-8")
        except UnicodeDecodeError:
            raise WorkspaceError("Not a UTF-8 text file.") from None

    def checkpoint(self):
        self._batch += 1

    def write(self, target, content):
        path = self.resolve(target)
        rel = path.relative_to(self.root)
        why = protected_reason(rel)
        if why:
            raise WorkspaceError(f"Refusing to write a protected path ({why}).")
        if path.is_dir():
            raise WorkspaceError("A directory with that name exists.")
        created = not path.exists()
        backup = None
        if not created:
            stamp = time.strftime("%Y%m%d_%H%M%S")
            backup = self.root / ".codex" / "backups" / f"{stamp}_{self._batch}" / rel
            backup.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(path, backup)
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.with_name(path.name + ".codex-tmp")
        tmp.write_text(content if content.endswith("\n") else content + "\n", encoding="utf-8")
        os.replace(tmp, path)
        self._undo.append((self._batch, path, backup))
        return WriteResult(path, rel.as_posix(), created)

    def undo(self):
        if not self._undo:
            return []
        batch = self._undo[-1][0]
        restored = []
        while self._undo and self._undo[-1][0] == batch:
            _, path, backup = self._undo.pop()
            if backup is None:
                path.unlink(missing_ok=True)
            else:
                shutil.copy2(backup, path)
            restored.append(path.relative_to(self.root).as_posix())
        return restored
