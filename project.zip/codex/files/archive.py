import os
import zipfile
from dataclasses import dataclass, field
from pathlib import Path

from codex.security import find_secrets, protected_reason

SCAN_LIMIT = 2_000_000
FIXED_DATE = (2020, 1, 1, 0, 0, 0)


class ArchiveError(Exception):
    pass


@dataclass
class ZipReport:
    path: Path
    included: list = field(default_factory=list)
    skipped: list = field(default_factory=list)


def build_zip(root, files, out):
    root = Path(root).resolve()
    entries, skipped = [], []
    for file in sorted({Path(f) for f in files}):
        label = str(file)
        try:
            if file.is_symlink() or not file.is_file():
                skipped.append((label, "not a regular file"))
                continue
            rel = file.resolve().relative_to(root)
        except (OSError, ValueError):
            skipped.append((label, "outside project or unreadable"))
            continue
        label = rel.as_posix()
        why = protected_reason(rel)
        if not why:
            data = file.read_bytes()
            found = find_secrets(data[:SCAN_LIMIT].decode("utf-8", "ignore"))
            why = f"contains a possible {found[0]}" if found else None
        if why:
            skipped.append((label, why))
            continue
        entries.append((label, data))

    if not entries:
        raise ArchiveError("Nothing safe to package.")

    out = Path(out)
    out.parent.mkdir(parents=True, exist_ok=True)
    tmp = out.with_suffix(".tmp")
    with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as zf:
        for label, data in entries:
            info = zipfile.ZipInfo(label, date_time=FIXED_DATE)
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o644 << 16
            zf.writestr(info, data)
    with zipfile.ZipFile(tmp) as zf:
        if zf.testzip() is not None:
            tmp.unlink()
            raise ArchiveError("The ZIP failed verification.")
    os.replace(tmp, out)
    return ZipReport(out, [label for label, _ in entries], skipped)
