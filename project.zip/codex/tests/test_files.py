import tempfile
import unittest
import zipfile
from pathlib import Path

from codex import security
from codex.files.archive import ArchiveError, build_zip
from codex.files.workspace import Workspace, WorkspaceError


class PathTests(unittest.TestCase):
    def setUp(self):
        self.root = Path(tempfile.mkdtemp())
        self.ws = Workspace(self.root / "ws")

    def test_traversal_rejected(self):
        for bad in ("../x.txt", "a/../../x.txt", "/etc/passwd", "~/../../etc/passwd"):
            with self.subTest(path=bad):
                with self.assertRaises(security.PathError):
                    self.ws.resolve(bad)

    def test_symlink_escape_rejected(self):
        (self.root / "secret.txt").write_text("x")
        (self.ws.root / "link").symlink_to(self.root / "secret.txt")
        with self.assertRaises(security.PathError):
            self.ws.resolve("link")

    def test_absolute_path_inside_workspace_ok(self):
        self.assertEqual(self.ws.resolve(str(self.ws.root / "a.py")), self.ws.root / "a.py")

    def test_write_outside_rejected(self):
        with self.assertRaises(security.PathError):
            self.ws.write("../evil.py", "x")
        self.assertFalse((self.root / "evil.py").exists())

    def test_cannot_write_env_or_keys(self):
        for name in (".env", "id_rsa", "x.pem", ".git/config"):
            with self.subTest(name=name):
                with self.assertRaises(WorkspaceError):
                    self.ws.write(name, "x")

    def test_protected_files_hidden_from_listing_and_reads(self):
        (self.ws.root / ".env").write_text("A=1")
        (self.ws.root / "a.py").write_text("1")
        self.assertEqual([p.name for p in self.ws.files()], ["a.py"])
        with self.assertRaises(WorkspaceError):
            self.ws.read(".env")

    def test_overwrite_makes_backup_and_undo_restores(self):
        self.ws.write("a.py", "one")
        self.ws.checkpoint()
        self.ws.write("a.py", "two")
        self.ws.write("b.py", "new")
        self.assertEqual(sorted(self.ws.undo()), ["a.py", "b.py"])
        self.assertEqual((self.ws.root / "a.py").read_text(), "one\n")
        self.assertFalse((self.ws.root / "b.py").exists())


class ArchiveTests(unittest.TestCase):
    def test_zip_filters_secrets_and_is_deterministic(self):
        root = Path(tempfile.mkdtemp())
        files = {
            "ok.py": "print(1)", ".env": "A=1", ".git/config": "[x]", "__pycache__/a.pyc": "x",
            "k.pem": "x", "leak.js": "const k = 'sk-abcdefghijklmnopqrstuvwxyz123456'", ".env.example": "A=",
        }
        for name, content in files.items():
            p = root / name
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_text(content)
        out = root / "out" / "p.zip"
        report = build_zip(root, [root / n for n in files], out)
        self.assertEqual(sorted(report.included), [".env.example", "ok.py"])
        self.assertEqual(len(report.skipped), 5)
        first = out.read_bytes()
        build_zip(root, [root / n for n in files], out)
        self.assertEqual(first, out.read_bytes())
        with zipfile.ZipFile(out) as zf:
            self.assertIsNone(zf.testzip())

    def test_empty_package_raises(self):
        root = Path(tempfile.mkdtemp())
        (root / ".env").write_text("A=1")
        with self.assertRaises(ArchiveError):
            build_zip(root, [root / ".env"], root / "o.zip")


if __name__ == "__main__":
    unittest.main()
