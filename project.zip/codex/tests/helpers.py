import json
import re
import tempfile
from pathlib import Path

from codex.config import Settings
from codex.http import Response

USER_ID = "111222333"
ADMIN_ID = "999888777"
BOT_TOKEN = "123456789:AAEhBOweik6ad8LmpyzaWyTsH-0pLoQ0abc"


def tg_ok(document=True):
    result = {"message_id": 7}
    if document:
        result["document"] = {"file_id": "x"}
    return Response(200, json.dumps({"ok": True, "result": result}).encode())


def tg_error(code, description, **extra):
    body = {"ok": False, "error_code": code, "description": description}
    body.update(extra)
    return Response(code, json.dumps(body).encode())


class FakeHttp:
    def __init__(self, *responses, default=None):
        self.responses = list(responses)
        self.default = default
        self.calls = []

    def __call__(self, method, url, headers, body, timeout):
        self.calls.append({"method": method, "url": url, "headers": headers, "body": body})
        if self.responses:
            return self.responses.pop(0)
        return self.default if self.default is not None else tg_ok()

    def chat_id(self, index=-1):
        call = self.calls[index]
        body = call["body"]
        if "multipart" in call["headers"].get("Content-Type", ""):
            return re.search(rb'name="chat_id"\r\n\r\n([^\r]+)', body).group(1).decode()
        return str(json.loads(body)["chat_id"])


def make_settings(tmp=None, **overrides):
    tmp = Path(tmp or tempfile.mkdtemp())
    settings = Settings(
        home=tmp / "home",
        workspace=tmp / "ws",
        bot_token=BOT_TOKEN,
        super_admin_id=ADMIN_ID,
        user_id=USER_ID,
    )
    for key, value in overrides.items():
        setattr(settings, key, value)
    return settings
