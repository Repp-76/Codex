import json
import unittest

from codex import ai
from codex.ai import Message, ProviderError
from codex.http import Response

from tests.helpers import FakeHttp

MSGS = [Message("user", "hello")]


def openai_ok(text="hi"):
    return Response(200, json.dumps({"choices": [{"message": {"content": text}}]}).encode())


def api_error(status, message):
    return Response(status, json.dumps({"error": {"message": message}}).encode())


def make(name, http, key="k" * 20):
    cls = ai.PROVIDERS[name]
    return cls(key, http=http)


class ProviderTests(unittest.TestCase):
    def test_openai_compatible_request_shape(self):
        for name, host in (("openai", "api.openai.com"), ("deepseek", "api.deepseek.com"), ("openrouter", "openrouter.ai")):
            with self.subTest(name=name):
                http = FakeHttp(openai_ok("done"))
                self.assertEqual(make(name, http).chat(MSGS, "sys"), "done")
                call = http.calls[0]
                self.assertIn(host, call["url"])
                self.assertTrue(call["url"].endswith("/chat/completions"))
                self.assertEqual(call["headers"]["Authorization"], "Bearer " + "k" * 20)
                payload = json.loads(call["body"])
                self.assertEqual(payload["messages"][0], {"role": "system", "content": "sys"})
                self.assertEqual(payload["messages"][1]["content"], "hello")

    def test_claude_request_and_parse(self):
        http = FakeHttp(Response(200, json.dumps({"content": [{"type": "text", "text": "a"}, {"type": "text", "text": "b"}]}).encode()))
        self.assertEqual(make("anthropic", http).chat(MSGS, "sys"), "ab")
        call = http.calls[0]
        self.assertEqual(call["headers"]["x-api-key"], "k" * 20)
        self.assertEqual(call["headers"]["anthropic-version"], "2023-06-01")
        payload = json.loads(call["body"])
        self.assertEqual(payload["system"], "sys")
        self.assertIn("max_tokens", payload)

    def test_gemini_request_and_parse(self):
        body = {"candidates": [{"content": {"parts": [{"text": "x"}, {"text": "y"}]}}]}
        http = FakeHttp(Response(200, json.dumps(body).encode()))
        provider = make("gemini", http)
        self.assertEqual(provider.chat([Message("user", "q"), Message("assistant", "a"), Message("user", "q2")], "sys"), "xy")
        call = http.calls[0]
        self.assertEqual(call["headers"]["x-goog-api-key"], "k" * 20)
        self.assertNotIn("k" * 20, call["url"])
        payload = json.loads(call["body"])
        self.assertEqual([c["role"] for c in payload["contents"]], ["user", "model", "user"])

    def test_invalid_key(self):
        for name in ai.PROVIDERS:
            with self.subTest(name=name):
                with self.assertRaises(ProviderError) as ctx:
                    make(name, FakeHttp(api_error(401, "Incorrect API key"))).chat(MSGS, "s")
                self.assertEqual(ctx.exception.kind, "auth")

    def test_failure_kinds(self):
        cases = [
            (api_error(429, "Rate limit reached"), "rate_limit"),
            (api_error(429, "You exceeded your current quota"), "quota"),
            (api_error(404, "The model `x` does not exist"), "invalid_model"),
            (api_error(400, "maximum context length is 8192 tokens"), "context_limit"),
            (api_error(400, "bad field"), "invalid_request"),
            (Response(503, b"<html>down</html>"), "outage"),
            (Response(529, b"{}"), "outage"),
            (Response(error="timeout"), "timeout"),
            (Response(error="dns"), "dns"),
            (Response(error="connection"), "connection"),
        ]
        for response, kind in cases:
            with self.subTest(kind=kind, status=response.status):
                with self.assertRaises(ProviderError) as ctx:
                    make("openai", FakeHttp(response)).chat(MSGS, "s")
                self.assertEqual(ctx.exception.kind, kind)

    def test_malformed_responses(self):
        bodies = [b"not json", b"[]", b"{}", b'{"choices": []}', b'{"choices": [{"message": {"content": ""}}]}']
        for body in bodies:
            with self.subTest(body=body):
                with self.assertRaises(ProviderError) as ctx:
                    make("openai", FakeHttp(Response(200, body))).chat(MSGS, "s")
                self.assertEqual(ctx.exception.kind, "malformed")
        with self.assertRaises(ProviderError):
            make("anthropic", FakeHttp(Response(200, b'{"content": "x"}'))).chat(MSGS, "s")
        with self.assertRaises(ProviderError):
            make("gemini", FakeHttp(Response(200, b'{"candidates": []}'))).chat(MSGS, "s")

    def test_error_inside_200_body(self):
        body = json.dumps({"error": {"message": "No credits", "code": 402}}).encode()
        with self.assertRaises(ProviderError) as ctx:
            make("openrouter", FakeHttp(Response(200, body))).chat(MSGS, "s")
        self.assertEqual(ctx.exception.kind, "quota")

    def test_error_messages_never_contain_key(self):
        key = "sk-abcdefghijklmnopqrstuvwxyz123456"
        with self.assertRaises(ProviderError) as ctx:
            make("openai", FakeHttp(api_error(401, f"Incorrect API key provided: {key}")), key=key).chat(MSGS, "s")
        self.assertNotIn(key, str(ctx.exception))

    def test_resolve_names(self):
        self.assertEqual(ai.resolve_name("Claude"), "anthropic")
        self.assertEqual(ai.resolve_name("openrouter"), "openrouter")
        self.assertIsNone(ai.resolve_name("nope"))


if __name__ == "__main__":
    unittest.main()
