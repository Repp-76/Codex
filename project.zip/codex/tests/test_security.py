import tempfile
import unittest
import zipfile
from pathlib import Path

from codex import security
from codex.files.archive import ArchiveError, build_zip
from codex.files.workspace import Workspace, WorkspaceError
from tests.helpers import BOT_TOKEN


class RedactionTests(unittest.TestCase):
    def test_api_keys(self):
        for key in ("sk-abcdefghijklmnopqrstuvwxyz123456", "sk-ant-api03-abcdefghijklmnopqrstuvwxyz", "sk-or-v1-abcdefghijklmnopqrstuvwxyz",
                    "AIzaSyA1234567890abcdefghijklmnopqrstuv", "ghp_" + "a" * 36):
            with self.subTest(key=key[:8]):
                self.assertNotIn(key, security.redact(f"error with {key} here"))

    def test_bot_token_plain_and_in_url(self):
        self.assertNotIn(BOT_TOKEN, security.redact(f"token {BOT_TOKEN}"))
        self.assertNotIn(BOT_TOKEN, security.redact(f"https://api.telegram.org/bot{BOT_TOKEN}/sendMessage"))

    def test_bearer_and_private_key(self):
        self.assertNotIn("abcdefghijklmnopqrstuvwx", security.redact("Authorization: Bearer abcdefghijklmnopqrstuvwx"))
        pem = "-----BEGIN PRIVATE KEY-----\nMIIabc\n-----END PRIVATE KEY-----"
        self.assertNotIn("MIIabc", security.redact(pem))

    def test_password_assignment(self):
        self.assertNotIn("hunter2hunter2", security.redact('password = "hunter2hunter2"'))

    def test_placeholders_and_normal_code_untouched(self):
        for text in ('api_key = "YOUR_API_KEY_HERE"', "token = os.environ['TOKEN']", "def get_token(self): pass"):
            self.assertEqual(security.redact(text), text)

    def test_registered_secret_is_hidden_anywhere(self):
        security.register_secrets(["plain-secret-value-1"])
        self.assertNotIn("plain-secret-value-1", security.redact("oops plain-secret-value-1"))
        self.assertIn("configured secret", security.find_secrets("x plain-secret-value-1"))
        security._known.discard("plain-secret-value-1")

    def test_find_secrets_clean_text(self):
        self.assertEqual(security.find_secrets("print('hello')\nname = 'codex'"), [])


if __name__ == "__main__":
    unittest.main()
