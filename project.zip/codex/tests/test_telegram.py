import tempfile
import unittest
from pathlib import Path

from codex.conversation import Conversation
from codex.telegram.client import TelegramClient
from codex.telegram.delivery import DeliveryManager
from codex.telegram.events import (
    ConversationExportedEvent,
    EventBus,
    FileCreatedEvent,
    FileModifiedEvent,
    ProjectCreatedEvent,
)
from codex.http import Response

from tests.helpers import ADMIN_ID, BOT_TOKEN, USER_ID, FakeHttp, make_settings, tg_error, tg_ok

SAFE_FILES = {
    "main.py": "print('hi')\n", "index.html": "<h1>hi</h1>\n", "style.css": "body{margin:0}\n",
    "app.js": "console.log(1)\n", "app.ts": "const a: number = 1\n", "App.jsx": "export default () => null\n",
    "App.tsx": "export default () => null\n", "data.json": '{"a": 1}\n', "feed.xml": "<a/>\n",
    "c.yaml": "a: 1\n", "c.yml": "a: 1\n", "c.toml": "a = 1\n", "c.ini": "[a]\n", "c.cfg": "[a]\n",
    "README.md": "# hi\n", "notes.txt": "hi\n", "q.sql": "select 1;\n", "run.sh": "echo hi\n",
    "run.bash": "echo hi\n", "run.ps1": "Write-Host hi\n", "run.bat": "echo hi\n", "a.php": "<?php echo 1;\n",
    "A.java": "class A {}\n", "a.kt": "fun main() {}\n", "a.go": "package main\n", "a.rs": "fn main() {}\n",
    "a.rb": "puts 1\n", "a.c": "int main(){}\n", "a.cpp": "int main(){}\n", "a.h": "#pragma once\n",
    "a.cs": "class A {}\n", "a.swift": "print(1)\n", "a.dart": "void main() {}\n", "a.lua": "print(1)\n",
}


class DeliveryCase(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp())
        self.settings = make_settings(self.tmp)
        self.ws = self.settings.workspace
        self.ws.mkdir(parents=True)
        self.lines = []
        self.confirms = []
        self.answer = False

    def manager(self, http, **kw):
        client = TelegramClient(BOT_TOKEN, http=http, sleep=lambda s: None)
        return DeliveryManager(
            self.settings, client, lambda: [self.ws, self.settings.home],
            lambda text, tone="info": self.lines.append(text), confirm=self._confirm, **kw,
        )

    def _confirm(self, question):
        self.confirms.append(question)
        return self.answer

    def write(self, name, content="print('hi')\n"):
        path = self.ws / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content)
        return path

    def text(self):
        return "\n".join(self.lines)


class ClientTests(unittest.TestCase):
    def test_message_ok(self):
        http = FakeHttp(tg_ok(document=False))
        res = TelegramClient(BOT_TOKEN, http=http).send_message(USER_ID, "hi")
        self.assertTrue(res.ok)
        self.assertEqual(res.message_id, 7)
        self.assertEqual(http.chat_id(), USER_ID)

    def test_document_ok_requires_document_in_response(self):
        tmp = Path(tempfile.mkdtemp()) / "a.txt"
        tmp.write_text("x")
        res = TelegramClient(BOT_TOKEN, http=FakeHttp(tg_ok(document=False))).send_document(USER_ID, tmp)
        self.assertFalse(res.ok)
        self.assertEqual(res.kind, "malformed")

    def test_http_200_with_ok_false_is_failure(self):
        res = TelegramClient(BOT_TOKEN, http=FakeHttp(Response(200, b'{"ok": false}'))).send_message("1", "x")
        self.assertFalse(res.ok)

    def test_error_classification(self):
        cases = [
            (tg_error(401, "Unauthorized"), "invalid_token"),
            (tg_error(400, "Bad Request: chat not found"), "chat_not_found"),
            (tg_error(400, "Bad Request: wrong user_id specified"), "invalid_user_id"),
            (tg_error(403, "Forbidden: bot was blocked by the user"), "bot_blocked"),
            (tg_error(403, "Forbidden: bot can't initiate conversation with a user"), "not_started"),
            (tg_error(400, "Bad Request: file is too big"), "too_large"),
            (tg_error(400, "Bad Request: something odd"), "api_error"),
            (Response(error="timeout"), "timeout"),
            (Response(error="dns"), "dns"),
            (Response(error="connection"), "connection"),
        ]
        for response, kind in cases:
            with self.subTest(kind=kind):
                res = TelegramClient(BOT_TOKEN, http=FakeHttp(response)).send_message("1", "x")
                self.assertFalse(res.ok)
                self.assertEqual(res.kind, kind)

    def test_timeout_is_uncertain(self):
        res = TelegramClient(BOT_TOKEN, http=FakeHttp(Response(error="timeout"))).send_message("1", "x")
        self.assertTrue(res.uncertain)

    def test_rate_limit_retries_once_then_succeeds(self):
        slept = []
        http = FakeHttp(tg_error(429, "Too Many Requests", parameters={"retry_after": 2}), tg_ok(document=False))
        res = TelegramClient(BOT_TOKEN, http=http, sleep=slept.append).send_message("1", "x")
        self.assertTrue(res.ok)
        self.assertEqual(slept, [2])
        self.assertEqual(len(http.calls), 2)

    def test_rate_limit_not_retried_forever(self):
        http = FakeHttp(default=tg_error(429, "Too Many Requests", parameters={"retry_after": 1}))
        res = TelegramClient(BOT_TOKEN, http=http, sleep=lambda s: None).send_message("1", "x")
        self.assertEqual(res.kind, "rate_limited")
        self.assertEqual(len(http.calls), 2)

    def test_not_started_message_matches_spec(self):
        res = TelegramClient(BOT_TOKEN, http=FakeHttp(tg_error(403, "Forbidden: bot can't initiate conversation with a user"))).send_message("1", "x")
        self.assertIn("Open the CODEX bot in Telegram and press Start", res.reason)
        self.assertNotIn("key", res.reason.lower())


class FileDeliveryTests(DeliveryCase):
    def test_every_file_type_is_sent_to_user_id(self):
        for name, content in SAFE_FILES.items():
            with self.subTest(name=name):
                http = FakeHttp()
                manager = self.manager(http)
                path = self.write(name, content)
                out = manager.handle(FileCreatedEvent(path))
                self.assertEqual(out[0].status, "sent", self.text())
                self.assertEqual(http.chat_id(), USER_ID)
                self.assertIn(f'filename="{name}"'.encode(), http.calls[0]["body"])

    def test_zip_file_is_sent(self):
        import zipfile

        path = self.ws / "bundle.zip"
        with zipfile.ZipFile(path, "w") as zf:
            zf.writestr("a.txt", "hi")
        out = self.manager(FakeHttp()).handle(FileCreatedEvent(path))
        self.assertEqual(out[0].status, "sent")

    def test_destination_is_never_super_admin(self):
        http = FakeHttp()
        self.manager(http).handle(FileCreatedEvent(self.write("a.py")))
        self.assertEqual(http.chat_id(), USER_ID)
        self.assertNotEqual(http.chat_id(), ADMIN_ID)
        self.assertNotIn(ADMIN_ID.encode(), http.calls[0]["body"])

    def test_sent_only_after_telegram_confirms(self):
        manager = self.manager(FakeHttp(tg_error(400, "Bad Request: nope")))
        out = manager.handle(FileCreatedEvent(self.write("a.py")))
        self.assertEqual(out[0].status, "failed")
        self.assertNotIn("SENT", self.text())
        self.assertIn("FAILED", self.text())
        self.assertIn("Reason:", self.text())

    def test_success_lines(self):
        self.manager(FakeHttp()).handle(FileCreatedEvent(self.write("index.html", "<p>x</p>")))
        self.assertEqual(
            self.lines,
            ["[TELEGRAM] Preparing: index.html", "[TELEGRAM] Uploading...", "[TELEGRAM] SENT: index.html"],
        )

    def test_timeout_reported_and_not_resent(self):
        http = FakeHttp(Response(error="timeout"))
        manager = self.manager(http)
        path = self.write("a.py")
        first = manager.handle(FileCreatedEvent(path))[0]
        second = manager.handle(FileCreatedEvent(path))[0]
        self.assertEqual(first.status, "failed")
        self.assertEqual(second.status, "skipped")
        self.assertEqual(len(http.calls), 1)

    def test_network_failure_can_be_retried_later(self):
        http = FakeHttp(Response(error="dns"))
        manager = self.manager(http)
        path = self.write("a.py")
        self.assertEqual(manager.handle(FileCreatedEvent(path))[0].status, "failed")
        self.assertEqual(manager.handle(FileCreatedEvent(path))[0].status, "sent")

    def test_duplicate_events_send_once(self):
        http = FakeHttp()
        manager = self.manager(http)
        bus = EventBus()
        bus.subscribe(manager.handle)
        bus.subscribe(manager.handle)
        path = self.write("a.py")
        bus.emit(FileCreatedEvent(path))
        bus.emit(FileModifiedEvent(path))
        self.assertEqual(len(http.calls), 1)

    def test_changed_content_is_sent_again(self):
        http = FakeHttp()
        manager = self.manager(http)
        path = self.write("a.py", "one\n")
        manager.handle(FileCreatedEvent(path))
        path.write_text("two\n")
        manager.handle(FileModifiedEvent(path))
        self.assertEqual(len(http.calls), 2)

    def test_force_resends(self):
        http = FakeHttp()
        manager = self.manager(http)
        path = self.write("a.py")
        manager.handle(FileCreatedEvent(path))
        manager.handle(FileCreatedEvent(path, explicit=True, force=True))
        self.assertEqual(len(http.calls), 2)

    def test_oversized_file_not_uploaded(self):
        import codex.telegram.delivery as delivery

        original = delivery.MAX_UPLOAD_BYTES
        delivery.MAX_UPLOAD_BYTES = 10
        try:
            http = FakeHttp()
            out = self.manager(http).handle(FileCreatedEvent(self.write("big.txt", "x" * 100)))
        finally:
            delivery.MAX_UPLOAD_BYTES = original
        self.assertEqual(out[0].status, "failed")
        self.assertEqual(http.calls, [])
        self.assertIn("exceeds the supported upload size", self.text())
        self.assertIn("remains available locally", self.text())
        self.assertNotIn("SENT", self.text())

    def test_protected_files_blocked(self):
        samples = {
            ".env": "A=1\n", "server.pem": "x\n", "id_rsa": "x\n", "credentials.json": "{}\n",
            "key.key": "x\n", ".git/config": "[core]\n", "node_modules/a.js": "1\n",
        }
        for name, content in samples.items():
            with self.subTest(name=name):
                http = FakeHttp()
                out = self.manager(http).handle(FileCreatedEvent(self.write(name, content)))
                self.assertEqual(out[0].status, "blocked")
                self.assertEqual(http.calls, [])

    def test_file_with_secret_content_blocked(self):
        for secret in (
            "key = 'sk-abcdefghijklmnopqrstuvwxyz123456'\n",
            "-----BEGIN RSA PRIVATE KEY-----\nabc\n-----END RSA PRIVATE KEY-----\n",
            f"TOKEN={BOT_TOKEN}\n",
        ):
            with self.subTest(secret=secret[:12]):
                http = FakeHttp()
                out = self.manager(http).handle(FileCreatedEvent(self.write("config.py", secret)))
                self.assertEqual(out[0].status, "blocked")
                self.assertEqual(http.calls, [])

    def test_env_example_allowed(self):
        out = self.manager(FakeHttp()).handle(FileCreatedEvent(self.write(".env.example", "OPENAI_API_KEY=\n")))
        self.assertEqual(out[0].status, "sent")

    def test_explicit_protected_send_needs_confirmation(self):
        path = self.write(".env", "A=1\n")
        http = FakeHttp()
        out = self.manager(http).handle(FileCreatedEvent(path, explicit=True, force=True))
        self.assertEqual(out[0].status, "blocked")
        self.assertEqual(len(self.confirms), 1)
        self.answer = True
        out = self.manager(http).handle(FileCreatedEvent(path, explicit=True, force=True))
        self.assertEqual(out[0].status, "sent")

    def test_automatic_events_never_ask_to_override(self):
        self.manager(FakeHttp()).handle(FileCreatedEvent(self.write(".env", "A=1\n")))
        self.assertEqual(self.confirms, [])

    def test_path_outside_workspace_rejected(self):
        outside = self.tmp / "outside.txt"
        outside.write_text("x")
        http = FakeHttp()
        out = self.manager(http).handle(FileCreatedEvent(outside))
        self.assertEqual(out[0].status, "failed")
        self.assertEqual(http.calls, [])

    def test_missing_user_id_fails_without_calling_telegram(self):
        self.settings.user_id = ""
        http = FakeHttp()
        out = self.manager(http).handle(FileCreatedEvent(self.write("a.py")))
        self.assertEqual(out[0].status, "failed")
        self.assertEqual(http.calls, [])

    def test_missing_token_fails_cleanly(self):
        manager = DeliveryManager(self.settings, None, lambda: [self.ws], lambda t, tone="info": self.lines.append(t))
        out = manager.handle(FileCreatedEvent(self.write("a.py")))
        self.assertEqual(out[0].status, "failed")

    def test_unexpected_exception_does_not_escape(self):
        class Boom:
            def send_document(self, *a, **k):
                raise RuntimeError("boom")

        manager = DeliveryManager(self.settings, Boom(), lambda: [self.ws], lambda t, tone="info": self.lines.append(t))
        out = manager.handle(FileCreatedEvent(self.write("a.py")))
        self.assertEqual(out[0].status, "failed")

    def test_auto_send_files_off(self):
        self.settings.auto_send_files = False
        http = FakeHttp()
        self.assertEqual(self.manager(http).handle(FileCreatedEvent(self.write("a.py"))), [])
        self.assertEqual(http.calls, [])

    def test_token_never_in_output(self):
        self.manager(FakeHttp(tg_error(400, f"Bad Request: {BOT_TOKEN}"))).handle(FileCreatedEvent(self.write("a.py")))
        self.assertNotIn(BOT_TOKEN, self.text())


class ProjectAndExportTests(DeliveryCase):
    def test_project_zip_excludes_secrets_and_is_sent(self):
        import zipfile

        files = [
            self.write("website/index.html", "<h1>x</h1>\n"),
            self.write("website/css/style.css", "a{}\n"),
            self.write("website/js/app.js", "1\n"),
            self.write("website/README.md", "# x\n"),
            self.write("website/.env", "SECRET=1\n"),
            self.write("website/keys.pem", "x\n"),
            self.write("website/node_modules/x.js", "1\n"),
            self.write("website/leak.py", "k = 'sk-abcdefghijklmnopqrstuvwxyz123456'\n"),
        ]
        http = FakeHttp()
        out = self.manager(http).handle(ProjectCreatedEvent(self.ws, files, "website"))
        self.assertEqual(out[0].status, "sent", self.text())
        self.assertEqual(http.chat_id(), USER_ID)
        with zipfile.ZipFile(self.settings.home / "out" / "website.zip") as zf:
            names = sorted(zf.namelist())
        self.assertEqual(names, ["website/README.md", "website/css/style.css", "website/index.html", "website/js/app.js"])
        self.assertIn("Excluded from ZIP: website/.env", self.text())
        self.assertIn("website/leak.py", self.text())

    def test_project_with_only_secrets_is_not_sent(self):
        http = FakeHttp()
        out = self.manager(http).handle(ProjectCreatedEvent(self.ws, [self.write(".env", "A=1\n")], "p"))
        self.assertEqual(out[0].status, "failed")
        self.assertEqual(http.calls, [])

    def test_project_event_repeated_sends_once(self):
        http = FakeHttp()
        manager = self.manager(http)
        files = [self.write("p/a.py"), self.write("p/b.py")]
        manager.handle(ProjectCreatedEvent(self.ws, files, "p"))
        manager.handle(ProjectCreatedEvent(self.ws, files, "p"))
        self.assertEqual(len(http.calls), 1)

    def test_auto_send_projects_off(self):
        self.settings.auto_send_projects = False
        http = FakeHttp()
        self.assertEqual(self.manager(http).handle(ProjectCreatedEvent(self.ws, [self.write("a.py")], "p")), [])

    def test_conversation_export_is_sanitized_and_sent(self):
        convo = Conversation()
        convo.add("user", f"my key is sk-abcdefghijklmnopqrstuvwxyz123456 and token {BOT_TOKEN}")
        convo.add("assistant", "Authorization: Bearer abcdefghijklmnopqrstuvwxyz123456\nDone.")
        path = convo.export(self.settings.home / "exports", markdown=True)[0]
        content = path.read_text()
        for leak in ("sk-abcdefghij", BOT_TOKEN, "abcdefghijklmnopqrstuvwxyz123456"):
            self.assertNotIn(leak, content)
        self.assertTrue(content.startswith("=" * 50 + "\nCODEX SESSION\n" + "=" * 50))
        self.assertIn("USER:\n", content)
        self.assertIn("CODEX:\n", content)
        http = FakeHttp()
        out = self.manager(http).handle(ConversationExportedEvent(path))
        self.assertEqual(out[0].status, "sent")
        self.assertEqual(http.chat_id(), USER_ID)

    def test_chat_not_auto_sent_unless_enabled(self):
        convo = Conversation()
        convo.add("user", "hi")
        path = convo.export(self.settings.home / "exports")[0]
        http = FakeHttp()
        self.assertEqual(self.manager(http).handle(ConversationExportedEvent(path, explicit=False)), [])
        self.settings.auto_send_chat = True
        self.assertEqual(self.manager(http).handle(ConversationExportedEvent(path, explicit=False))[0].status, "sent")


class AdminTests(DeliveryCase):
    def test_new_user_notification_goes_to_admin_only(self):
        http = FakeHttp(tg_ok(document=False))
        out = self.manager(http).notify_admin_new_user("555666777")
        self.assertEqual(out.status, "sent")
        self.assertEqual(http.chat_id(), ADMIN_ID)
        body = http.calls[0]["body"].decode()
        for part in ("[CODEX] New user configuration", "Telegram ID: 555666777", "Status: Configured", "Timestamp:"):
            self.assertIn(part, body)
        self.assertNotIn(BOT_TOKEN, body)

    def test_admin_failure_is_reported_not_raised(self):
        out = self.manager(FakeHttp(Response(error="dns"))).notify_admin_new_user("555666777")
        self.assertEqual(out.status, "failed")

    def test_user_and_admin_ids_stay_separate(self):
        http = FakeHttp(default=tg_ok(document=False))
        manager = self.manager(http)
        manager.notify_admin_new_user("42424242")
        manager.send_test()
        self.assertEqual([http.chat_id(0), http.chat_id(1)], [ADMIN_ID, USER_ID])
        self.assertEqual(self.settings.user_id, USER_ID)
        self.assertEqual(self.settings.super_admin_id, ADMIN_ID)


if __name__ == "__main__":
    unittest.main()
