import json
import re
import stat
import unittest
import tempfile
from pathlib import Path

from codex import config
from codex.cli import USER_ID_PATTERN
from codex.config import PROJECT_ROOT

ENV_EXAMPLE = (PROJECT_ROOT / ".env.example").read_text()


class UserIdStorageTests(unittest.TestCase):
    def setUp(self):
        self.home = Path(tempfile.mkdtemp()) / "home"
        self.env = {"TELEGRAM_BOT_TOKEN": "tok", "TELEGRAM_SUPER_ADMIN_ID": "42"}

    def load(self, **extra):
        return config.load(home=self.home, cwd=self.home.parent, environ={**self.env, **extra})

    def test_env_example_does_not_ask_for_user_id(self):
        assert_lines = [l for l in ENV_EXAMPLE.splitlines() if not l.startswith("#")]
        self.assertFalse(any(l.startswith("TELEGRAM_USER_ID") for l in assert_lines))
        self.assertIn("TELEGRAM_SUPER_ADMIN_ID=", ENV_EXAMPLE)

    def test_no_user_id_needed_in_env(self):
        self.assertEqual(self.load().user_id, "")

    def test_user_id_in_env_is_ignored(self):
        self.assertEqual(self.load(TELEGRAM_USER_ID="777888999").user_id, "")

    def test_saved_locally_and_reloaded(self):
        settings = self.load()
        settings.set_user_id("123456789")
        saved = json.loads((self.home / "user.json").read_text())
        self.assertEqual(saved["telegram_user_id"], "123456789")
        self.assertNotIn("tok", json.dumps(saved))
        self.assertEqual(self.load().user_id, "123456789")
        self.assertEqual(self.load().super_admin_id, "42")

    def test_user_file_is_private(self):
        settings = self.load()
        settings.set_user_id("123456789")
        mode = stat.S_IMODE((self.home / "user.json").stat().st_mode)
        self.assertEqual(mode & 0o077, 0)

    def test_changing_id_replaces_old(self):
        settings = self.load()
        settings.set_user_id("123456789")
        settings.set_user_id("987654321")
        self.assertEqual(self.load().user_id, "987654321")

    def test_corrupt_user_file_does_not_crash(self):
        self.home.mkdir(parents=True)
        (self.home / "user.json").write_text("{nope")
        self.assertEqual(self.load().user_id, "")

    def test_id_validation(self):
        for good in ("12345", "7624612389", "123456789012345"):
            self.assertTrue(USER_ID_PATTERN.fullmatch(good), good)
        for bad in ("", "1234", "1234567890123456", "12 345", "abc12345", "123456;ls", "123456\n", "-12345", "$(id)"):
            self.assertFalse(USER_ID_PATTERN.fullmatch(bad), repr(bad))

    def test_defaults_to_project_root_workspace(self):
        self.assertEqual(self.load().workspace, PROJECT_ROOT / "workspace")

    def test_no_numeric_ids_hardcoded_in_source(self):
        pattern = re.compile(r"(?<![\w.])\d{8,}(?![\w.])")
        for path in (PROJECT_ROOT / "codex").rglob("*.py"):
            self.assertIsNone(pattern.search(path.read_text()), str(path))
        for name in ("README.md", ".env.example", "requirements.txt"):
            self.assertIsNone(pattern.search((PROJECT_ROOT / name).read_text()), name)


class LayoutTests(unittest.TestCase):
    def test_single_obvious_root(self):
        for name in ("main.py", "requirements.txt", ".env.example", "README.md", "codex/__init__.py", "tests"):
            self.assertTrue((PROJECT_ROOT / name).exists(), name)
        self.assertFalse((PROJECT_ROOT / "codex" / "codex").exists())
        self.assertFalse((PROJECT_ROOT / "codex" / "main.py").exists())

    def test_readme_never_tells_user_to_put_id_in_env(self):
        readme = (PROJECT_ROOT / "README.md").read_text()
        self.assertNotIn("TELEGRAM_USER_ID=", readme)


if __name__ == "__main__":
    unittest.main()


class ModelPersistenceTests(unittest.TestCase):
    def test_env_models_are_not_frozen_into_user_file(self):
        home = Path(tempfile.mkdtemp()) / "h"
        settings = config.load(home=home, cwd=home.parent, environ={"OPENAI_MODEL": "from-env"})
        settings.set_user_id("123456789")
        self.assertEqual(json.loads((home / "user.json").read_text())["models"], {})
        settings.saved_models["openai"] = "chosen"
        settings.save_state()
        again = config.load(home=home, cwd=home.parent, environ={"OPENAI_MODEL": "from-env"})
        self.assertEqual(again.models["openai"], "chosen")
