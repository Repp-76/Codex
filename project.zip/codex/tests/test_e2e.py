import io
import json
import sys
import tempfile
import unittest
import zipfile
from pathlib import Path
from unittest import mock

from codex.agent import Agent
from codex.ai import ProviderError
from codex.cli import Cli
from codex.config import PROVIDER_ORDER
from codex.conversation import Conversation
from codex.files.workspace import Workspace
from codex.http import Response
from codex.telegram.client import TelegramClient
from codex.telegram.delivery import DeliveryManager
from codex.telegram.events import EventBus
from codex.terminal import TerminalManager
from codex.ui import UI

from tests.helpers import ADMIN_ID, BOT_TOKEN, USER_ID, FakeHttp, make_settings


class ScriptedProvider:
    name = "openai"
    label = "OpenAI"
    env_key = "OPENAI_API_KEY"
    model = "test-model"
    configured = True

    def __init__(self):
        self.replies = []
        self.seen = []

    def chat(self, messages, system):
        self.seen.append((list(messages), system))
        reply = self.replies.pop(0)
        if isinstance(reply, Exception):
            raise reply
        return reply


def file_block(path, content):
    return f'<file path="{path}">\n{content}\n</file>'


class EndToEnd(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp())
        self.settings = make_settings(self.tmp, user_id="")
        self.stream = io.StringIO()
        self.term = TerminalManager(self.stream)
        self.ui = UI(self.term)
        self.workspace = Workspace(self.settings.workspace)
        self.conversation = Conversation()
        self.agent = Agent(self.workspace, self.conversation)
        self.http = FakeHttp()
        self.client = TelegramClient(BOT_TOKEN, http=self.http, sleep=lambda s: None)
        self.delivery = DeliveryManager(
            self.settings, self.client, lambda: [self.workspace.root, self.settings.home], self.ui.note,
        )
        self.bus = EventBus()
        self.bus.subscribe(self.delivery.handle)
        self.provider = ScriptedProvider()
        providers = {n: self.provider for n in PROVIDER_ORDER}
        self.cli = Cli(self.term, self.ui, self.settings, self.workspace, providers, self.conversation,
                       self.agent, self.delivery, self.bus, self.client)

    def out(self):
        return self.stream.getvalue()

    def test_full_flow(self):
        # first run: ID entered, admin notified, user ID stored separately
        with mock.patch.object(self.ui, "ask", return_value="555123456"):
            self.cli.first_run_telegram()
        self.assertEqual(self.settings.user_id, "555123456")
        self.assertEqual(self.settings.super_admin_id, ADMIN_ID)
        self.assertEqual(self.http.chat_id(0), ADMIN_ID)
        self.assertIn(b"Telegram ID: 555123456", self.http.calls[0]["body"])
        self.assertEqual(json.loads(self.settings.state_path.read_text())["telegram_user_id"], "555123456")

        # single file
        self.provider.replies.append("Here you go.\n" + file_block("test.py", "print('hello')"))
        self.cli.ask("Create test.py")
        self.assertTrue((self.workspace.root / "test.py").is_file())
        self.assertEqual(self.http.chat_id(-1), "555123456")
        self.assertIn("[TELEGRAM] SENT: test.py", self.out())
        self.assertNotIn("<file", self.out())

        # multi-file project with a secret file that must not ship
        self.provider.replies.append(
            "\n".join([
                "Project ready.",
                file_block("website/index.html", "<h1>x</h1>"),
                file_block("website/css/style.css", "a{}"),
                file_block("website/js/app.js", "console.log(1)"),
                file_block("website/README.md", "# site"),
                file_block("website/.env", "SECRET=abc"),
            ])
        )
        before = len(self.http.calls)
        self.cli.ask("Build a website")
        self.assertEqual(len(self.http.calls), before + 1)
        self.assertEqual(self.http.chat_id(-1), "555123456")
        self.assertFalse((self.workspace.root / "website" / ".env").exists())
        with zipfile.ZipFile(self.settings.home / "out" / "website.zip") as zf:
            self.assertEqual(
                sorted(zf.namelist()),
                ["website/README.md", "website/css/style.css", "website/index.html", "website/js/app.js"],
            )

        # export is sanitized and goes to the user's ID
        self.conversation.add("user", "my key sk-abcdefghijklmnopqrstuvwxyz123456")
        before = len(self.http.calls)
        self.cli.command("/send-chat")
        self.assertEqual(len(self.http.calls), before + 1)
        self.assertEqual(self.http.chat_id(-1), "555123456")
        exported = next((self.settings.home / "exports").glob("codex_session_*.txt")).read_text()
        self.assertNotIn("sk-abcdefghij", exported)
        self.assertIn("USER:", exported)

        # Telegram goes down: CODEX carries on, file stays local, failure is shown honestly
        self.http.default = Response(error="dns")
        self.provider.replies.append(file_block("later.py", "print(2)"))
        self.cli.ask("Create later.py")
        self.assertTrue((self.workspace.root / "later.py").is_file())
        self.assertIn("[TELEGRAM] FAILED", self.out())
        self.assertNotIn("SENT: later.py", self.out())

        # provider goes down: error shown, session intact
        turns = len(self.conversation.turns)
        self.provider.replies.append(ProviderError("rate_limit"))
        self.cli.ask("anything")
        self.assertIn("Rate limit", self.out())
        self.assertEqual(len(self.conversation.turns), turns)
        self.provider.replies.append("Still alive.")
        self.cli.ask("hello again")
        self.assertIn("Still alive.", self.out())

    def test_invalid_id_reprompts_then_saves(self):
        answers = iter(["abc", "12 34", "123456789"])
        with mock.patch.object(self.ui, "ask", side_effect=lambda q: next(answers)):
            self.assertTrue(self.cli.link_telegram())
        self.assertEqual(self.settings.user_id, "123456789")
        self.assertEqual(len(self.http.calls), 1)

    def test_no_valid_id_after_three_tries_saves_nothing(self):
        with mock.patch.object(self.ui, "ask", return_value="nope"):
            self.assertFalse(self.cli.link_telegram())
        self.assertEqual(self.settings.user_id, "")
        self.assertEqual(self.http.calls, [])

    def test_telegram_command_changes_id_and_notifies_admin(self):
        self.settings.user_id = "111222333"
        with mock.patch.object(self.ui, "ask", return_value="444555666"):
            self.cli.command("/telegram")
        self.assertEqual(self.settings.user_id, "444555666")
        self.assertEqual(self.http.chat_id(-1), ADMIN_ID)
        self.assertIn("Current status: Configured", self.out())
        self.assertNotIn("111222333", self.out())
        self.provider.replies.append(file_block("x.py", "1"))
        self.cli.ask("make x.py")
        self.assertEqual(self.http.chat_id(-1), "444555666")

    def test_saved_id_is_not_asked_again(self):
        self.settings.user_id = "111222333"
        with mock.patch.object(self.ui, "ask") as ask:
            self.cli.first_run_telegram()
        ask.assert_not_called()

    def test_modified_file_gets_backup_and_context(self):
        self.settings.user_id = USER_ID
        (self.workspace.root / "app.py").write_text("print('v1')\n")
        self.provider.replies.append(file_block("app.py", "print('v2')"))
        self.cli.ask("Update app.py to print v2")
        system = self.provider.seen[-1][1]
        self.assertIn("print('v1')", system)
        self.assertEqual((self.workspace.root / "app.py").read_text(), "print('v2')\n")
        self.cli.command("/undo")
        self.assertEqual((self.workspace.root / "app.py").read_text(), "print('v1')\n")

    def test_ai_cannot_write_outside_workspace_or_env(self):
        self.settings.user_id = USER_ID
        self.provider.replies.append(file_block("../evil.py", "x") + file_block(".env", "A=1") + file_block("ok.py", "1"))
        self.cli.ask("go")
        self.assertFalse((self.workspace.root.parent / "evil.py").exists())
        self.assertFalse((self.workspace.root / ".env").exists())
        self.assertTrue((self.workspace.root / "ok.py").exists())
        self.assertIn("skipped", self.out())

    def test_commands(self):
        self.settings.user_id = USER_ID
        (self.workspace.root / "a.py").write_text("print('x')\n")
        (self.workspace.root / ".env").write_text("SECRET=1\n")
        for line in ("/help", "/files", "/show a.py", "/open a.py", "/provider", "/model", "/project", "/status", "/telegram", "/nope"):
            self.cli.command(line)
        out = self.out()
        self.assertIn("/send-chat", out)
        self.assertIn("a.py", out)
        self.assertNotIn("SECRET=1", out)
        self.assertIn("Unknown command", out)
        self.assertEqual(self.cli.command("/exit"), False)
        self.cli.command("/show ../../etc/passwd")
        self.assertIn("outside the workspace", self.out())

    def test_run_after_confirmation_and_fix_uses_error(self):
        (self.workspace.root / "bad.py").write_text("raise SystemExit(3)\n")
        with mock.patch.object(self.ui, "confirm", return_value=True):
            self.cli.command("/run bad.py")
        self.assertIn("Exit code 3", self.out())
        self.assertEqual(self.cli.last_error[0], "bad.py")
        self.provider.replies.append("looked")
        self.cli.command("/fix")
        self.assertIn("Running it failed", self.provider.seen[-1][0][-1].content)

    def test_run_declined_and_dangerous_refused(self):
        (self.workspace.root / "ok.py").write_text("open('ran.txt','w')\n")
        with mock.patch.object(self.ui, "confirm", return_value=False):
            self.cli.command("/run ok.py")
        self.assertFalse((self.workspace.root / "ran.txt").exists())
        (self.workspace.root / "wipe.sh").write_text("rm -rf /\n")
        with mock.patch.object(self.ui, "confirm", return_value=True):
            self.cli.command("/run wipe.sh")
        self.assertIn("destructive", self.out())

    def test_run_strips_secrets_from_environment(self):
        (self.workspace.root / "env.py").write_text("import os; print(os.environ.get('OPENAI_API_KEY'), os.environ.get('TELEGRAM_BOT_TOKEN'))\n")
        with mock.patch.dict("os.environ", {"OPENAI_API_KEY": "sk-secretsecretsecret1234", "TELEGRAM_BOT_TOKEN": BOT_TOKEN}), \
                mock.patch.object(self.ui, "confirm", return_value=True):
            self.cli.command("/run env.py")
        self.assertIn("None None", self.out())

    def test_provider_switch_requires_key_and_is_explicit(self):
        class Bare(ScriptedProvider):
            configured = False
            label = "DeepSeek"
            env_key = "DEEPSEEK_API_KEY"

        self.cli.providers["deepseek"] = Bare()
        self.cli.command("/provider deepseek")
        self.assertEqual(self.settings.provider, "openai")
        self.assertIn("DEEPSEEK_API_KEY", self.out())

    def test_loop_survives_errors_and_exits(self):
        self.provider.replies.append(RuntimeError("kaboom"))
        with mock.patch.object(sys, "stdin", io.StringIO("do something\n/help\n/exit\n")):
            code = self.cli.loop()
        self.assertEqual(code, 0)
        self.assertIn("Unexpected error: kaboom", self.out())
        self.assertIn("Commands", self.out())

    def test_multiline_triple_quote_input(self):
        with mock.patch.object(sys, "stdin", io.StringIO('"""\nline one\nline two\n"""\n')):
            text = self.ui.read_prompt()
        self.assertEqual(text, "line one\nline two")

    def test_conversation_history_trimmed_from_oldest(self):
        convo = Conversation()
        for i in range(10):
            convo.add("user", "u" * 100)
            convo.add("assistant", "a" * 100)
        msgs = convo.messages(budget=450)
        self.assertEqual(msgs[0].role, "user")
        self.assertLess(len(msgs), 20)


if __name__ == "__main__":
    unittest.main()
