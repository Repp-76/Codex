import re
from pathlib import Path

REDACTED = "[REDACTED]"

_TOKEN_PATTERNS = [
    ("private key", re.compile(r"-----BEGIN [A-Z ]*PRIVATE KEY-----[\s\S]*?(?:-----END [A-Z ]*PRIVATE KEY-----|\Z)")),
    ("API key", re.compile(r"\bsk-[A-Za-z0-9_\-]{20,}")),
    ("Google API key", re.compile(r"\bAIza[0-9A-Za-z_\-]{35}")),
    ("GitHub token", re.compile(r"\bgh[pousr]_[A-Za-z0-9]{36,}")),
    ("AWS access key", re.compile(r"\bAKIA[0-9A-Z]{16}\b")),
    ("Telegram bot token", re.compile(r"(?<!\d)\d{8,10}:[A-Za-z0-9_\-]{35}(?![A-Za-z0-9_\-])")),
    ("Bearer token", re.compile(r"(?i)\bbearer\s+[A-Za-z0-9._~+/\-]{16,}=*")),
]

_ASSIGNMENT = re.compile(
    r"""(?ix)
    ((?:api[_-]?key|secret|token|passwd|password|authorization)\w*["']?\s*[:=]\s*)
    (["'])([^"'\s]{8,})\2
    """
)
_PLACEHOLDER = re.compile(r"(?i)your|example|xxx|changeme|placeholder|<|\*\*\*|redacted|dummy|sample|todo")

_known = set()


def register_secrets(values):
    for value in values:
        if value and len(value) >= 8:
            _known.add(value)


def redact(text):
    if not text:
        return text
    for value in sorted(_known, key=len, reverse=True):
        text = text.replace(value, REDACTED)
    for _, pattern in _TOKEN_PATTERNS:
        text = pattern.sub(REDACTED, text)

    def hide(match):
        if _PLACEHOLDER.search(match.group(3)):
            return match.group(0)
        return f"{match.group(1)}{match.group(2)}{REDACTED}{match.group(2)}"

    return _ASSIGNMENT.sub(hide, text)


def find_secrets(text):
    """Names of secret types found in text; empty when it looks clean."""
    found = []
    for name, pattern in _TOKEN_PATTERNS:
        if pattern.search(text):
            found.append(name)
    for match in _ASSIGNMENT.finditer(text):
        if not _PLACEHOLDER.search(match.group(3)):
            found.append("hard-coded credential")
            break
    if any(value in text for value in _known):
        found.append("configured secret")
    return found


PROTECTED_DIRS = {
    ".git", ".svn", ".hg", "node_modules", ".venv", "venv", "__pycache__",
    ".ssh", ".aws", ".gnupg", ".cache", ".mypy_cache", ".pytest_cache", ".codex",
}
PROTECTED_FILES = {
    "id_rsa", "id_dsa", "id_ecdsa", "id_ed25519", "credentials.json",
    "secrets.json", ".git-credentials", ".netrc", ".npmrc", ".pypirc",
    "service-account.json",
}
PROTECTED_SUFFIXES = {
    ".pem", ".key", ".p12", ".pfx", ".jks", ".keystore", ".kdbx", ".ppk",
    ".gpg", ".pyc", ".pyo",
}
_ENV_TEMPLATES = (".example", ".sample", ".template")


def protected_reason(rel):
    """Why a project-relative path must never be sent automatically, or None."""
    rel = Path(rel)
    for part in rel.parts[:-1]:
        if part in PROTECTED_DIRS:
            return f"protected directory ({part})"
    name = rel.name.lower()
    if name in PROTECTED_DIRS:
        return f"protected directory ({name})"
    if name in PROTECTED_FILES:
        return "credentials file"
    if name == ".env" or name.endswith(".env") or name.startswith(".env."):
        if not name.endswith(_ENV_TEMPLATES):
            return "environment file"
    if Path(name).suffix in PROTECTED_SUFFIXES:
        return "key or cache file"
    return None


class PathError(ValueError):
    pass


def resolve_in(root, target):
    root = Path(root).resolve()
    text = str(target)
    if not text.strip() or "\x00" in text:
        raise PathError("Invalid path.")
    candidate = Path(text)
    if not candidate.is_absolute():
        candidate = root / candidate
    resolved = candidate.resolve()
    if resolved != root and root not in resolved.parents:
        raise PathError("Path is outside the workspace.")
    return resolved
