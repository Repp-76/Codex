from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class FileCreatedEvent:
    path: Path
    explicit: bool = False
    force: bool = False


@dataclass
class FileModifiedEvent:
    path: Path
    explicit: bool = False
    force: bool = False


@dataclass
class ProjectCreatedEvent:
    root: Path
    files: list = field(default_factory=list)
    name: str = "project"
    explicit: bool = False
    force: bool = False


@dataclass
class ConversationExportedEvent:
    path: Path
    explicit: bool = True
    force: bool = False


class EventBus:
    def __init__(self):
        self._handlers = []

    def subscribe(self, handler):
        if handler not in self._handlers:
            self._handlers.append(handler)

    def emit(self, event):
        results = []
        for handler in list(self._handlers):
            results.extend(handler(event) or [])
        return results
