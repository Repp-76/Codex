import hashlib
import os
import threading
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path

from codex.files.archive import ArchiveError, build_zip
from codex.security import find_secrets, protected_reason
from codex.telegram.client import MAX_UPLOAD_BYTES
from codex.telegram.events import (
    ConversationExportedEvent,
    FileCreatedEvent,
    FileModifiedEvent,
    ProjectCreatedEvent,
)

SCAN_LIMIT = 2_000_000


@dataclass
class Outcome:
    status: str  # sent, failed, blocked, skipped
    name: str
    reason: str = ""


class DeliveryManager:
    """Consumes events and uploads to the user's own Telegram ID, never the admin's."""

    def __init__(self, settings, client, roots, report, confirm=None):
        self.settings = settings
        self.client = client
        self.roots = roots
        self.report = report
        self.confirm = confirm
        self._lock = threading.Lock()
        self._delivered = set()
        self._uncertain = set()
        self._inflight = set()

    def _say(self, text, tone="info"):
        self.report(f"[TELEGRAM] {text}", tone)

    def _fail(self, name, reason, status="failed"):
        self._say("FAILED" if status == "failed" else "BLOCKED", "error" if status == "failed" else "warn")
        self._say(f"Reason: {reason}", "error" if status == "failed" else "warn")
        return Outcome(status, name, reason)

    def handle(self, event):
        try:
            if isinstance(event, (FileCreatedEvent, FileModifiedEvent)):
                if event.explicit or self.settings.auto_send_files:
                    return [self._send_file(event.path, event.explicit, event.force)]
            elif isinstance(event, ProjectCreatedEvent):
                if event.explicit or self.settings.auto_send_projects:
                    return [self._send_project(event)]
            elif isinstance(event, ConversationExportedEvent):
                if event.explicit or self.settings.auto_send_chat:
                    return [self._send_file(event.path, event.explicit, event.force)]
        except Exception as exc:  # delivery must never take CODEX down
            return [self._fail(getattr(event, "name", "event"), f"{type(exc).__name__}: unexpected delivery error")]
        return []

    def _ready_problem(self):
        if self.client is None:
            return "TELEGRAM_BOT_TOKEN is not set."
        if not self.settings.user_id:
            return "No Telegram ID set. Use /telegram id."
        return None

    def _locate(self, path):
        try:
            resolved = Path(path).resolve(strict=True)
        except OSError:
            return None, None
        for root in self.roots():
            root = Path(root).resolve()
            if resolved == root or root in resolved.parents:
                return resolved, resolved.relative_to(root)
        return None, None

    def _send_file(self, path, explicit=False, force=False, trusted=False):
        name = Path(path).name
        problem = self._ready_problem()
        if problem:
            return self._fail(name, problem)
        self._say(f"Preparing: {name}")

        resolved, rel = self._locate(path)
        if resolved is None:
            return self._fail(name, "File not found or outside the workspace.")
        if not resolved.is_file() or not os.access(resolved, os.R_OK):
            return self._fail(name, "Not a readable regular file.")
        size = resolved.stat().st_size
        if size > MAX_UPLOAD_BYTES:
            self._say("File exceeds the supported upload size.", "warn")
            self._say("The file remains available locally.", "warn")
            return Outcome("failed", name, "file too large")
        if size == 0:
            return self._fail(name, "The file is empty.")

        data = resolved.read_bytes()
        if not trusted:
            why = protected_reason(rel)
            if not why:
                found = find_secrets(data[:SCAN_LIMIT].decode("utf-8", "ignore"))
                why = f"contains a possible {found[0]}" if found else None
            if why:
                approved = explicit and self.confirm and self.confirm(
                    f"{name} looks sensitive ({why}). Send it to Telegram anyway?"
                )
                if not approved:
                    return self._fail(name, why, status="blocked")

        key = (str(resolved), hashlib.sha256(data).hexdigest())
        with self._lock:
            if not force:
                if key in self._delivered:
                    self._say(f"Skipped: {name} was already delivered.")
                    return Outcome("skipped", name, "already delivered")
                if key in self._uncertain:
                    self._say(f"Skipped: an earlier upload of {name} timed out and may have arrived.", "warn")
                    self._say("Use /send to send it again.", "warn")
                    return Outcome("skipped", name, "earlier upload uncertain")
                if key in self._inflight:
                    return Outcome("skipped", name, "upload in progress")
            self._inflight.add(key)

        try:
            self._say("Uploading...")
            result = self.client.send_document(self.settings.user_id, resolved, caption=name)
        finally:
            with self._lock:
                self._inflight.discard(key)

        if result.ok:
            with self._lock:
                self._delivered.add(key)
                self._uncertain.discard(key)
            self._say(f"SENT: {name}", "ok")
            return Outcome("sent", name)
        if result.uncertain:
            with self._lock:
                self._uncertain.add(key)
            reason = f"{result.reason} It will not be re-sent automatically."
        else:
            reason = result.reason
        return self._fail(name, reason)

    def _send_project(self, event):
        problem = self._ready_problem()
        if problem:
            return self._fail(event.name, problem)
        out = self.settings.home / "out" / f"{event.name}.zip"
        try:
            report = build_zip(event.root, event.files, out)
        except ArchiveError as exc:
            return self._fail(event.name, str(exc))
        for rel, why in report.skipped:
            self._say(f"Excluded from ZIP: {rel} ({why})", "warn")
        self._say(f"Packaged {len(report.included)} files into {out.name}")
        return self._send_file(report.path, event.explicit, event.force, trusted=True)

    def notify_admin_new_user(self, user_id):
        admin = self.settings.super_admin_id
        if self.client is None or not admin:
            return Outcome("skipped", "admin", "super admin not configured")
        stamp = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
        text = f"[CODEX] New user configuration\nTelegram ID: {user_id}\nStatus: Configured\nTimestamp: {stamp}"
        result = self.client.send_message(admin, text)
        if result.ok:
            return Outcome("sent", "admin")
        return Outcome("failed", "admin", result.reason)

    def send_test(self):
        problem = self._ready_problem()
        if problem:
            return Outcome("failed", "test", problem)
        result = self.client.send_message(self.settings.user_id, "[CODEX] Test message. Telegram delivery is working.")
        if result.ok:
            return Outcome("sent", "test")
        return Outcome("failed", "test", result.reason)
