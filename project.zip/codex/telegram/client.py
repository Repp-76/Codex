import json
import time
from dataclasses import dataclass

from codex.http import encode_multipart, json_headers, request
from codex.security import redact

API = "https://api.telegram.org"
MAX_UPLOAD_BYTES = 50 * 1024 * 1024
MAX_TEXT = 4096

REASONS = {
    "invalid_token": "The bot token was rejected by Telegram. Check TELEGRAM_BOT_TOKEN.",
    "invalid_user_id": "Telegram rejected the user ID. Check the ID you entered.",
    "chat_not_found": "Telegram could not find this chat. Check the ID and make sure you opened the bot and pressed Start.",
    "not_started": "Delivery unavailable. Open the CODEX bot in Telegram and press Start, then try again.",
    "bot_blocked": "The bot is blocked by this user. Unblock it in Telegram and press Start.",
    "rate_limited": "Telegram rate limit reached. Try again shortly.",
    "too_large": "The file exceeds the supported upload size.",
    "timeout": "The request timed out. It may or may not have been delivered.",
    "dns": "DNS lookup failed. Check your internet connection.",
    "connection": "Could not reach Telegram. Check your internet connection.",
    "malformed": "Telegram returned a response CODEX could not verify.",
    "api_error": "Telegram rejected the request.",
}


@dataclass
class TgResult:
    ok: bool
    kind: str = ""
    description: str = ""
    message_id: int = 0
    uncertain: bool = False

    @property
    def reason(self):
        text = REASONS.get(self.kind, "Telegram request failed.")
        if self.kind in ("api_error", "malformed") and self.description:
            text = f"{text} {redact(self.description)}"
        return text


def _classify(status, data):
    desc = ""
    code = status
    retry_after = 0
    if isinstance(data, dict):
        desc = str(data.get("description") or "")
        code = data.get("error_code") or status
        retry_after = int((data.get("parameters") or {}).get("retry_after") or 0)
    low = desc.lower()
    if code == 401:
        kind = "invalid_token"
    elif code == 429:
        kind = "rate_limited"
    elif code == 413 or "too big" in low or "too large" in low:
        kind = "too_large"
    elif "blocked by the user" in low:
        kind = "bot_blocked"
    elif "can't initiate conversation" in low or "bot can't send messages to bots" in low:
        kind = "not_started"
    elif "chat not found" in low:
        kind = "chat_not_found"
    elif "user_id" in low or "peer_id_invalid" in low or "invalid user" in low:
        kind = "invalid_user_id"
    else:
        kind = "api_error"
    uncertain = isinstance(status, int) and status >= 500
    return TgResult(False, kind, desc, uncertain=uncertain), retry_after


class TelegramClient:
    def __init__(self, token, http=request, sleep=time.sleep):
        self._token = token
        self.http = http
        self.sleep = sleep

    def _call(self, method, body, content_type, timeout, expect=None):
        url = f"{API}/bot{self._token}/{method}"
        headers = {"Content-Type": content_type}
        for attempt in (0, 1):
            resp = self.http("POST", url, headers, body, timeout)
            if resp.error:
                return TgResult(False, resp.error, uncertain=resp.error == "timeout")
            data = resp.json()
            if resp.status == 200 and isinstance(data, dict) and data.get("ok") is True:
                result = data.get("result")
                if isinstance(result, dict) and result.get("message_id") and (not expect or expect in result):
                    return TgResult(True, message_id=int(result["message_id"]))
                return TgResult(False, "malformed", uncertain=True)
            failure, retry_after = _classify(resp.status, data)
            if failure.kind == "rate_limited" and attempt == 0 and 0 < retry_after <= 10:
                self.sleep(retry_after)
                continue
            return failure
        return TgResult(False, "rate_limited")

    def get_me(self):
        url = f"{API}/bot{self._token}/getMe"
        resp = self.http("GET", url, {}, None, 8)
        if resp.error:
            return TgResult(False, resp.error)
        data = resp.json()
        if resp.status == 200 and isinstance(data, dict) and data.get("ok") is True:
            return TgResult(True)
        return _classify(resp.status, data)[0]

    def send_message(self, chat_id, text):
        body = json.dumps({"chat_id": chat_id, "text": text[:MAX_TEXT]}).encode("utf-8")
        return self._call("sendMessage", body, json_headers()["Content-Type"], 20)

    def send_document(self, chat_id, path, caption=""):
        data = path.read_bytes()
        if len(data) > MAX_UPLOAD_BYTES:
            return TgResult(False, "too_large")
        fields = {"chat_id": chat_id}
        if caption:
            fields["caption"] = caption[:1000]
        body, content_type = encode_multipart(fields, "document", path.name, data)
        return self._call("sendDocument", body, content_type, 180, expect="document")
