# CODEX

Terminal AI coding assistant by Repp76. Python 3.9+, standard library only.
Providers: OpenAI, Claude, Gemini, DeepSeek, OpenRouter. Generated files and projects
are delivered to your own Telegram ID.

## Project root

The folder that contains `main.py` is the project root:

    main.py  requirements.txt  .env.example  README.md  codex/  tests/

Unzip `codex.zip` straight into an empty folder. There is no extra `codex/` wrapper folder.

## First run (Termux, Linux, macOS)

    mkdir -p ~/codex-app && cd ~/codex-app
    unzip ~/path/to/codex.zip
    python -m pip install -r requirements.txt
    cp .env.example .env
    nano .env
    python main.py

On Termux, run `pkg install python unzip` once first.
Windows: `py main.py` from the project root.

In `.env` fill in only `TELEGRAM_BOT_TOKEN`, `TELEGRAM_SUPER_ADMIN_ID` and the API keys
you use. Then:

1. Open your bot in Telegram and press **Start**.
2. Run `python main.py`. CODEX clears the screen, shows the banner and status, then asks
   `Enter your Telegram ID:`.
3. Type your numeric Telegram ID. CODEX validates it, saves it locally in
   `~/.codex/user.json`, and notifies the super admin.
4. Ask for a file, for example `Create test.html`. It is sent to your Telegram.

Next runs show `User ID: Configured` (the ID itself is never printed). Change it any time
with `/telegram`.

`TELEGRAM_SUPER_ADMIN_ID` (owner, receives new-user notices only) and your user ID
(receives your files) are different values and are never mixed.

## Configure

Optional `.env` values: `CODEX_WORKSPACE` (default `<project root>/workspace`),
`CODEX_HOME` (default `~/.codex`), `<PROVIDER>_MODEL`, for example `OPENAI_MODEL=gpt-4.1`.
Default model names are only starting points; change them with `/model`.

`python main.py --debug` also prints the project root and entry point, and full tracebacks.

## Commands

| Command | Action |
|---|---|
| `/help` `/clear` `/exit` `/status` | basics |
| `/telegram` | show Telegram status and change your Telegram ID |
| `/telegram test` | send a test message to your Telegram |
| `/provider [name]` `/model [name]` | show or switch (no silent fallback) |
| `/project [path]` `/files` | workspace |
| `/open` `/show` `/edit` `/fix` `/run` `/undo` | work with files |
| `/new` | fresh conversation |
| `/export [md]` `/send-chat` | sanitized transcript, optionally sent |
| `/send <file or folder>` | send manually (folders become a ZIP) |

Type a request and press Enter. Paste multi-line text directly, or wrap it in `"""` lines.

## Safety

- Writes stay inside the workspace; `../` and outside absolute paths are rejected.
- `.env`, keys, credentials, `.git`, `node_modules`, caches are never read, written, zipped or auto-sent. File contents are scanned for API keys, tokens and private keys.
- Secrets are redacted from errors, exports and `/show`.
- `/run` asks first, refuses destructive patterns, times out at 60 s, and strips keys from the child environment.
- Overwrites are backed up under `.codex/backups`; `/undo` reverts the last batch.

## Tests

    python -m unittest discover -s tests -t .

Telegram and providers are mocked, so these tests do not prove real delivery.
A pseudo-terminal test runs `python main.py` and checks the clear is the first output.

## Manual Telegram test

1. Put the bot token and your admin ID in `.env`; press Start on the bot.
2. `python main.py`, enter your Telegram ID.
3. `/telegram test`: the message should arrive.
4. Ask `Create test.html`; confirm `workspace/test.html` exists and arrives in Telegram.
5. The terminal must show `[TELEGRAM] SENT: test.html` only after the upload finished.
6. Disconnect the network and repeat: `[TELEGRAM] FAILED` with a reason, and CODEX keeps running.

## Troubleshooting

- **Nothing happens / `No module named codex`:** you are not in the project root. Run `ls`; you must see `main.py`, then `python main.py`.
- **Delivery unavailable / chat not found:** open the bot, press Start, check the ID with `/telegram`.
- **Invalid token:** recheck `TELEGRAM_BOT_TOKEN`.
- **Upload timed out:** the file may have arrived; CODEX will not resend automatically. Use `/send`.
- **API key rejected / invalid model:** check the key; use `/model <name>`.
- **Garbled colors:** set `NO_COLOR=1`.
