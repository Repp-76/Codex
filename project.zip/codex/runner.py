import os
import re
import subprocess
import sys
from dataclasses import dataclass

from codex.security import redact

RUNNERS = {
    ".py": [sys.executable],
    ".js": ["node"],
    ".sh": ["bash"],
    ".bash": ["bash"],
    ".php": ["php"],
    ".rb": ["ruby"],
    ".lua": ["lua"],
    ".go": ["go", "run"],
}
DANGEROUS = re.compile(
    r"rm\s+-[a-z]*r[a-z]*f?[a-z]*\s+(/|~|\$HOME)(\s|$)|mkfs|dd\s+if=.*of=/dev/|:\(\)\s*\{|>\s*/dev/sd|\bshutdown\b|\breboot\b"
)
SENSITIVE_ENV = {"TELEGRAM_BOT_TOKEN", "TELEGRAM_SUPER_ADMIN_ID", "TELEGRAM_USER_ID"}


class RunRefused(Exception):
    pass


@dataclass
class RunResult:
    command: list
    code: int
    output: str
    timed_out: bool = False


def command_for(path, args=()):
    base = RUNNERS.get(path.suffix.lower())
    if base is None:
        raise RunRefused(f"Don't know how to run {path.suffix or 'this'} files.")
    return [*base, str(path), *args]


def check_safe(text):
    if DANGEROUS.search(text):
        raise RunRefused("The file contains a destructive command pattern, so CODEX will not run it.")


def run(command, cwd, timeout=60):
    env = {
        k: v for k, v in os.environ.items()
        if not k.endswith("_API_KEY") and k not in SENSITIVE_ENV
    }
    try:
        proc = subprocess.run(
            command, cwd=cwd, env=env, stdin=subprocess.DEVNULL,
            capture_output=True, text=True, timeout=timeout, errors="replace",
        )
    except FileNotFoundError:
        return RunResult(command, 127, f"'{command[0]}' is not installed or not on PATH.")
    except subprocess.TimeoutExpired as exc:
        partial = exc.stdout if isinstance(exc.stdout, str) else ""
        return RunResult(command, 124, redact(partial)[-4000:], timed_out=True)
    output = redact((proc.stdout or "") + (proc.stderr or ""))
    return RunResult(command, proc.returncode, output[-6000:])
