import json
import socket
import urllib.error
import urllib.request
import uuid
from dataclasses import dataclass


@dataclass
class Response:
    status: int = 0
    body: bytes = b""
    error: str = ""  # "", "timeout", "dns" or "connection"
    detail: str = ""

    def json(self):
        try:
            return json.loads(self.body.decode("utf-8"))
        except (ValueError, UnicodeDecodeError):
            return None


def request(method, url, headers=None, body=None, timeout=30):
    req = urllib.request.Request(url, data=body, method=method, headers=headers or {})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return Response(status=resp.status, body=resp.read())
    except urllib.error.HTTPError as exc:
        try:
            payload = exc.read()
        except OSError:
            payload = b""
        return Response(status=exc.code, body=payload)
    except urllib.error.URLError as exc:
        reason = exc.reason
        if isinstance(reason, (TimeoutError, socket.timeout)):
            return Response(error="timeout")
        if isinstance(reason, socket.gaierror):
            return Response(error="dns", detail=str(reason))
        return Response(error="connection", detail=str(reason))
    except (TimeoutError, socket.timeout):
        return Response(error="timeout")
    except OSError as exc:
        return Response(error="connection", detail=str(exc))


def json_headers(extra=None):
    headers = {"Content-Type": "application/json"}
    headers.update(extra or {})
    return headers


def encode_multipart(fields, file_field, filename, data):
    boundary = uuid.uuid4().hex
    parts = []
    for key, value in fields.items():
        parts.append(
            f'--{boundary}\r\nContent-Disposition: form-data; name="{key}"\r\n\r\n{value}\r\n'.encode("utf-8")
        )
    safe_name = filename.replace('"', "_").replace("\r", "_").replace("\n", "_")
    parts.append(
        (
            f'--{boundary}\r\nContent-Disposition: form-data; name="{file_field}"; '
            f'filename="{safe_name}"\r\nContent-Type: application/octet-stream\r\n\r\n'
        ).encode("utf-8")
    )
    parts.append(data)
    parts.append(f"\r\n--{boundary}--\r\n".encode("utf-8"))
    return b"".join(parts), f"multipart/form-data; boundary={boundary}"
