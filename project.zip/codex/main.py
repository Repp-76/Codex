import sys

from codex.startup import main

if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
