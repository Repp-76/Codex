import sys
import textwrap

from codex import __version__

RESET = "\x1b[0m"
COLORS = {
    "red": "\x1b[38;5;160m",
    "hot": "\x1b[1;38;5;196m",
    "dim": "\x1b[38;5;244m",
    "white": "\x1b[38;5;253m",
    "wine": "\x1b[38;5;89m",
}
TONES = {"info": "dim", "ok": "white", "warn": "hot", "error": "hot"}


class UI:
    def __init__(self, term, out=None):
        self.term = term
        self.out = out if out is not None else term.stream
        self.color = term.supports_color()

    def paint(self, text, color):
        return f"{COLORS[color]}{text}{RESET}" if self.color else text

    def write(self, text=""):
        self.out.write(text + "\n")
        self.out.flush()

    def width(self):
        return max(40, min(self.term.width(), 96))

    def banner(self):
        inner = min(self.width() - 2, 54)
        edge = "═" * inner
        rows = ["", "C  O  D  E  X", "AI  CODE  ENGINE", ""]
        self.write("")
        self.write(self.paint(f"╔{edge}╗", "red"))
        for i, row in enumerate(rows):
            body = self.paint(row.center(inner), "hot" if i == 1 else "dim")
            self.write(self.paint("║", "red") + body + self.paint("║", "red"))
        self.write(self.paint(f"╚{edge}╝", "red"))
        self.write("")

    def basic_info(self):
        for label, value in (("Developer", "Repp76"), ("Version", __version__), ("Mode", "AI Coding Assistant")):
            self.write(f"  {self.paint(label.ljust(12), 'dim')}{self.paint(value, 'white')}")
        self.write("")

    def note(self, text, tone="info"):
        self.write(self.paint(text, TONES.get(tone, "dim")))

    def error(self, text):
        self.write(self.paint(f"[ERROR] {text}", "hot"))

    def section(self, title, rows):
        self.write(self.paint(f"[ {title} ]", "red"))
        for label, value, tone in rows:
            self.write(f"  {self.paint(label.ljust(14), 'dim')}: {self.paint(value, tone)}")
        self.write("")

    def panel(self, title, text, color="red"):
        width = self.width()
        head = f"╭─ {title} "
        self.write(self.paint(head + "─" * max(4, width - len(head)), color))
        for line in (text or "").split("\n"):
            indent = line[: len(line) - len(line.lstrip(" "))]
            wrapped = textwrap.wrap(
                line, width - 3, initial_indent="", subsequent_indent=indent,
                replace_whitespace=False, drop_whitespace=False,
            ) or [""]
            for part in wrapped:
                self.write(self.paint("│", color) + " " + part)
        self.write(self.paint("╰" + "─" * (width - 1), color))

    def read_prompt(self):
        """Read one request. Handles pasted blocks, triple-quote blocks and trailing backslashes."""
        width = self.width()
        head = "╭─ USER "
        self.write(self.paint(head + "─" * max(4, width - len(head)), "wine"))
        bar = self.paint("│", "wine") + " "
        try:
            first = input(bar)
        except EOFError:
            return None
        except KeyboardInterrupt:
            self.write("")
            return ""
        try:
            lines = self._more_lines(first, bar)
        except (EOFError, KeyboardInterrupt):
            lines = [first]
        self.write(self.paint("╰" + "─" * (width - 1), "wine"))
        return "\n".join(lines).strip()

    def _more_lines(self, first, bar):
        stripped = first.strip()
        if stripped.startswith('"""'):
            body = stripped[3:]
            if body.endswith('"""') and len(stripped) >= 6:
                return [body[:-3]]
            lines = [body] if body else []
            while True:
                line = input(bar)
                if line.strip().endswith('"""'):
                    tail = line.rstrip()[:-3]
                    if tail:
                        lines.append(tail)
                    return lines
                lines.append(line)
        lines = [first]
        while lines[-1].endswith("\\"):
            lines[-1] = lines[-1][:-1]
            lines.append(input(bar))
        lines.extend(self._pasted())
        return lines

    def _pasted(self):
        try:
            import select

            if not sys.stdin.isatty():
                return []
            extra = []
            while select.select([sys.stdin], [], [], 0.04)[0]:
                line = sys.stdin.readline()
                if not line:
                    break
                extra.append(line.rstrip("\n"))
            return extra
        except (ImportError, OSError, ValueError):
            return []

    def confirm(self, question):
        try:
            answer = input(self.paint(f"{question} [y/N] ", "hot"))
        except (EOFError, KeyboardInterrupt):
            self.write("")
            return False
        return answer.strip().lower() in ("y", "yes")

    def ask(self, question):
        try:
            return input(self.paint(question, "white") + " ").strip()
        except (EOFError, KeyboardInterrupt):
            self.write("")
            return ""

    def box(self, title, lines, color="red"):
        width = self.width()
        head = f"┌─ {title} "
        self.write(self.paint(head + "─" * max(2, width - len(head) - 1) + "┐", color))
        for line in lines:
            pad = " " * max(0, width - 4 - len(line))
            self.write(self.paint("│", color) + f" {line}{pad} " + self.paint("│", color))
        self.write(self.paint("└" + "─" * (width - 2) + "┘", color))

    def thinking(self, label):
        if self.color:
            self.out.write(self.paint(f"  {label} is working...", "dim"))
            self.out.flush()

    def done_thinking(self):
        if self.color:
            self.out.write("\r\x1b[K")
            self.out.flush()
