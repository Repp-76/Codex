import contextlib
import io
import os
import shutil
import sys
import warnings

CLEAR_SEQUENCE = "\x1b[0m\x1b[?25h\x1b[3J\x1b[2J\x1b[H"
RESET_SEQUENCE = "\x1b[0m\x1b[?25h\x1b[H"


class TerminalManager:
    def __init__(self, stream=None):
        self.stream = stream if stream is not None else sys.stdout
        self.cleared = False

    def is_tty(self):
        try:
            return bool(self.stream.isatty())
        except (AttributeError, ValueError):
            return False

    def supports_color(self):
        return self.is_tty() and "NO_COLOR" not in os.environ and os.environ.get("TERM") != "dumb"

    def width(self):
        return shutil.get_terminal_size((80, 24)).columns

    def height(self):
        return shutil.get_terminal_size((80, 24)).lines

    def _enable_windows_ansi(self):
        if os.name != "nt":
            return True
        try:
            import ctypes

            kernel = ctypes.windll.kernel32
            handle = kernel.GetStdHandle(-11)
            mode = ctypes.c_uint32()
            if not kernel.GetConsoleMode(handle, ctypes.byref(mode)):
                return False
            return bool(kernel.SetConsoleMode(handle, mode.value | 0x0004))
        except Exception:
            return False

    def _write(self, text):
        self.stream.write(text)
        self.stream.flush()

    def clear_screen(self):
        """Wipe screen and scrollback and home the cursor. Returns True if a clear was issued."""
        if not self.is_tty():
            return False
        try:
            if not self._enable_windows_ansi():
                os.system("cls")
                self._write(RESET_SEQUENCE)
            else:
                self._write(CLEAR_SEQUENCE)
        except (OSError, ValueError):
            return False
        self.cleared = True
        return True

    def reset(self):
        if not self.is_tty():
            return
        try:
            self._write(RESET_SEQUENCE)
        except (OSError, ValueError):
            pass


@contextlib.contextmanager
def quiet():
    """Swallow stdout, stderr and warnings produced while services initialise."""
    sink = io.StringIO()
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        with contextlib.redirect_stdout(sink), contextlib.redirect_stderr(sink):
            yield
