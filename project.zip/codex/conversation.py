import time
from pathlib import Path

from codex.ai.base import Message
from codex.security import redact

RULE = "=" * 50


class Conversation:
    def __init__(self):
        self.turns = []

    def add(self, role, text):
        self.turns.append((role, text))

    def pop(self):
        if self.turns:
            self.turns.pop()

    def reset(self):
        self.turns.clear()

    def messages(self, budget=150_000):
        picked, used = [], 0
        for role, text in reversed(self.turns):
            used += len(text)
            if used > budget and picked:
                break
            picked.append(Message("user" if role == "user" else "assistant", text))
        picked.reverse()
        while picked and picked[0].role != "user":
            picked.pop(0)
        return picked

    def render_txt(self):
        out = [RULE, "CODEX SESSION", RULE, ""]
        for role, text in self.turns:
            out += ["USER:" if role == "user" else "CODEX:", redact(text), ""]
        return "\n".join(out)

    def render_md(self):
        out = ["# CODEX Session", ""]
        for role, text in self.turns:
            out += ["## User" if role == "user" else "## CODEX", "", redact(text), ""]
        return "\n".join(out)

    def export(self, directory, markdown=False):
        directory = Path(directory)
        directory.mkdir(parents=True, exist_ok=True)
        stamp = time.strftime("%Y%m%d_%H%M%S")
        base = directory / f"codex_session_{stamp}"
        n = 1
        while base.with_suffix(".txt").exists():
            base = directory / f"codex_session_{stamp}_{n}"
            n += 1
        paths = [base.with_suffix(".txt")]
        paths[0].write_text(self.render_txt(), encoding="utf-8")
        if markdown:
            paths.append(base.with_suffix(".md"))
            paths[1].write_text(self.render_md(), encoding="utf-8")
        return paths
