import re
import traceback
from pathlib import Path

from codex import ai, runner
from codex.ai import ProviderError
from codex.config import PROVIDER_ORDER
from codex.files.workspace import WorkspaceError
from codex.security import PathError, redact
from codex.telegram.events import (
    ConversationExportedEvent,
    FileCreatedEvent,
    ProjectCreatedEvent,
)

USER_ID_PATTERN = re.compile(r"\d{5,15}")

HELP = """Commands
  /help                    Show this help
  /clear                   Clear the screen
  /exit                    Quit CODEX
  /provider [name]         Show or switch provider (openai, claude, gemini, deepseek, openrouter)
  /model [name]            Show or set the model for the active provider
  /project [path]          Show or switch the workspace folder
  /files                   List workspace files
  /open <file>             Add a file to the AI's context
  /show <file>             Print a file
  /edit <file> <task>      Ask CODEX to change a file
  /fix [file]              Ask CODEX to fix a file (uses the last run error)
  /run <file> [args]       Run a file after confirmation
  /undo                    Revert the last set of file changes
  /new                     Start a fresh conversation
  /export [md]             Save a sanitized session transcript
  /send-chat               Export the session and send it to Telegram
  /send <file|folder>      Send a file, or a folder as a ZIP, to Telegram
  /telegram                Show Telegram status and change your Telegram ID
  /telegram test           Send a test message to your Telegram
  /status                  Show system status

Anything else is sent to the AI. For long input, start with \"\"\" and end with \"\"\"
on its own line, or just paste it."""


class Cli:
    def __init__(self, term, ui, settings, workspace, providers, conversation, agent, delivery, bus, client):
        self.term = term
        self.ui = ui
        self.settings = settings
        self.workspace = workspace
        self.providers = providers
        self.conversation = conversation
        self.agent = agent
        self.delivery = delivery
        self.bus = bus
        self.client = client
        self.last_error = None
        self.debug = False

    @property
    def provider(self):
        return self.providers[self.settings.provider]

    def report(self, text, tone="info"):
        self.ui.note(text, tone)

    def first_run_telegram(self):
        if self.settings.user_id:
            return
        self.link_telegram()

    def link_telegram(self):
        """Ask for the Telegram ID in the terminal; True when a new ID was saved."""
        self.ui.box("TELEGRAM CONFIGURATION", ["Enter your Telegram ID:"])
        for _ in range(3):
            value = self.ui.ask(">")
            if not value:
                self.ui.note("Skipped. Run /telegram to set it later.")
                return False
            if USER_ID_PATTERN.fullmatch(value):
                break
            self.ui.error("A Telegram ID is 5 to 15 digits, with no spaces or other characters.")
        else:
            return False
        self.settings.set_user_id(value)
        self.ui.note("Telegram ID saved locally.", "ok")
        outcome = self.delivery.notify_admin_new_user(value)
        if outcome.status == "failed":
            self.ui.note(f"[TELEGRAM] Admin notification failed: {outcome.reason}", "warn")
        elif outcome.status == "skipped":
            self.ui.note("[TELEGRAM] Admin notification skipped: bot token or super admin ID missing in .env.")
        self.ui.write("")
        return True

    def loop(self):
        while True:
            try:
                line = self.ui.read_prompt()
            except KeyboardInterrupt:
                continue
            if line is None:
                return 0
            if not line:
                continue
            try:
                if line.startswith("/"):
                    if self.command(line) is False:
                        return 0
                else:
                    self.ask(line)
            except KeyboardInterrupt:
                self.ui.note("Cancelled.", "warn")
            except Exception as exc:  # keep the session alive whatever happens
                self.ui.error(f"Unexpected error: {redact(str(exc))}")
                if self.debug:
                    self.ui.write(redact(traceback.format_exc()))

    def command(self, line):
        name, _, rest = line.partition(" ")
        name = name.lower()
        rest = rest.strip()
        handlers = {
            "/help": lambda: self.ui.write(HELP),
            "/clear": self.cmd_clear,
            "/exit": lambda: False,
            "/quit": lambda: False,
            "/provider": lambda: self.cmd_provider(rest),
            "/model": lambda: self.cmd_model(rest),
            "/project": lambda: self.cmd_project(rest),
            "/files": self.cmd_files,
            "/open": lambda: self.cmd_open(rest),
            "/show": lambda: self.cmd_show(rest),
            "/edit": lambda: self.cmd_edit(rest),
            "/fix": lambda: self.cmd_fix(rest),
            "/run": lambda: self.cmd_run(rest),
            "/undo": self.cmd_undo,
            "/new": self.cmd_new,
            "/export": lambda: self.cmd_export(rest),
            "/send-chat": self.cmd_send_chat,
            "/send": lambda: self.cmd_send(rest),
            "/telegram": lambda: self.cmd_telegram(rest),
            "/telegram-id": lambda: self.cmd_telegram(""),
            "/status": self.cmd_status,
        }
        handler = handlers.get(name)
        if handler is None:
            self.ui.error(f"Unknown command {name}. Type /help.")
            return None
        try:
            return handler()
        except (PathError, WorkspaceError) as exc:
            self.ui.error(str(exc))
            return None

    def ask(self, prompt):
        provider = self.provider
        if not provider.configured:
            self.ui.error(f"{provider.label} has no API key. Set {provider.env_key} in .env or use /provider.")
            return
        self.ui.thinking(provider.label)
        try:
            result = self.agent.run(prompt, provider)
        except ProviderError as exc:
            self.ui.done_thinking()
            self.ui.error(f"{provider.label}: {exc}")
            return
        except KeyboardInterrupt:
            self.ui.done_thinking()
            raise
        self.ui.done_thinking()
        if result.text:
            self.ui.panel("CODEX", result.text)
        for change in result.changes:
            verb = "created " if change.created else "modified"
            self.ui.note(f"  {verb} {change.rel} ({change.lines} lines)", "ok")
        for rel, why in result.skipped:
            self.ui.note(f"  skipped  {rel}: {why}", "warn")
        for event in result.events:
            self.bus.emit(event)

    def cmd_clear(self):
        self.term.clear_screen()
        self.ui.banner()

    def cmd_provider(self, arg):
        if not arg:
            for name in PROVIDER_ORDER:
                p = self.providers[name]
                mark = ">" if name == self.settings.provider else " "
                state = "configured" if p.configured else "no key"
                self.ui.write(f" {mark} {p.label.ljust(11)} {p.model.ljust(32)} {state}")
            return
        name = ai.resolve_name(arg)
        if not name:
            self.ui.error("Unknown provider. Choose openai, claude, gemini, deepseek or openrouter.")
            return
        p = self.providers[name]
        if not p.configured:
            self.ui.error(f"{p.label} has no API key. Set {p.env_key} in .env first.")
            return
        self.settings.provider = name
        self.settings.save_state()
        self.ui.note(f"Active: {p.label} / {p.model}", "ok")

    def cmd_model(self, arg):
        p = self.provider
        if not arg:
            self.ui.write(f"{p.label} / {p.model}")
            return
        p.model = arg
        self.settings.models[p.name] = arg
        self.settings.saved_models[p.name] = arg
        self.settings.save_state()
        self.ui.note(f"Active: {p.label} / {p.model}", "ok")

    def cmd_project(self, arg):
        if not arg:
            self.ui.write(str(self.workspace.root))
            return
        self.workspace.set_root(Path(arg))
        self.agent.focus.clear()
        self.ui.note(f"Workspace: {self.workspace.root}", "ok")

    def cmd_files(self):
        files = self.workspace.files()
        if not files:
            self.ui.write("The workspace is empty.")
        for f in files:
            self.ui.write(f"  {self.workspace.rel(f).ljust(44)} {f.stat().st_size:>8} B")

    def cmd_open(self, arg):
        text = self.workspace.read(self._need(arg, "/open <file>"))
        rel = self.workspace.rel(self.workspace.resolve(arg))
        if rel not in self.agent.focus:
            self.agent.focus.append(rel)
        self.ui.note(f"Opened {rel} ({text.count(chr(10)) + 1} lines). It will be included with your requests.", "ok")

    def cmd_show(self, arg):
        text = self.workspace.read(self._need(arg, "/show <file>"))
        self.ui.panel(arg, redact(text), "dim")

    def cmd_edit(self, arg):
        target, _, task = arg.partition(" ")
        if not target or not task.strip():
            self.ui.error("Usage: /edit <file> <what to change>")
            return
        self.workspace.read(target)
        self.ask(f"Edit {target}: {task.strip()}")

    def cmd_fix(self, arg):
        target = arg or (self.last_error[0] if self.last_error else "")
        if not target:
            self.ui.error("Usage: /fix <file>")
            return
        self.workspace.read(target)
        prompt = f"Find and fix the problems in {target}."
        if self.last_error and self.last_error[0] == target:
            prompt += f"\nRunning it failed with:\n{self.last_error[1]}"
        self.ask(prompt)

    def cmd_run(self, arg):
        parts = arg.split()
        if not parts:
            self.ui.error("Usage: /run <file> [args]")
            return
        path = self.workspace.resolve(parts[0])
        text = self.workspace.read(parts[0])
        try:
            command = runner.command_for(path, parts[1:])
            runner.check_safe(text)
        except runner.RunRefused as exc:
            self.ui.error(str(exc))
            return
        self.ui.note("Command: " + " ".join(command), "info")
        if not self.ui.confirm("Run this command?"):
            return
        result = runner.run(command, self.workspace.root)
        if result.output.strip():
            self.ui.panel("OUTPUT", result.output.rstrip(), "dim")
        if result.timed_out:
            self.ui.note("Stopped after the 60 second limit.", "warn")
        self.ui.note(f"Exit code {result.code}", "ok" if result.code == 0 else "warn")
        rel = self.workspace.rel(path)
        self.last_error = (rel, result.output[-3000:]) if result.code != 0 else None
        if result.code != 0:
            self.ui.note(f"Use /fix to have CODEX repair {rel}.", "info")

    def cmd_undo(self):
        restored = self.workspace.undo()
        if not restored:
            self.ui.note("Nothing to undo.")
        for rel in restored:
            self.ui.note(f"  reverted {rel}", "ok")

    def cmd_new(self):
        self.conversation.reset()
        self.ui.note("Started a new conversation.", "ok")

    def _export(self, markdown):
        if not self.conversation.turns:
            self.ui.note("Nothing to export yet.")
            return []
        paths = self.conversation.export(self.settings.home / "exports", markdown)
        for p in paths:
            self.ui.note(f"Exported {p}", "ok")
        return paths

    def cmd_export(self, arg):
        self._export(arg.lower() == "md")

    def cmd_send_chat(self):
        paths = self._export(False)
        if paths:
            self.bus.emit(ConversationExportedEvent(paths[0], explicit=True))

    def cmd_send(self, arg):
        target = self.workspace.resolve(self._need(arg, "/send <file|folder>"))
        if target.is_dir():
            files = [p for p in target.rglob("*") if p.is_file()]
            self.bus.emit(ProjectCreatedEvent(self.workspace.root, files, target.name, explicit=True, force=True))
        elif target.is_file():
            self.bus.emit(FileCreatedEvent(target, explicit=True, force=True))
        else:
            self.ui.error("File not found.")

    def cmd_telegram(self, arg):
        if arg == "test":
            outcome = self.delivery.send_test()
            if outcome.status == "sent":
                self.ui.note("[TELEGRAM] SENT: test message", "ok")
            else:
                self.ui.note("[TELEGRAM] FAILED", "error")
                self.ui.note(f"Reason: {outcome.reason}", "error")
            return
        self.ui.write("Telegram configuration")
        self.ui.write("")
        self.ui.write(f"  Bot token   : {'Configured' if self.client else 'Missing (.env)'}")
        self.ui.write(f"  Super admin : {'Configured' if self.settings.super_admin_id else 'Missing (.env)'}")
        self.ui.write(f"  Current status: {'Configured' if self.settings.user_id else 'Not set'}")
        self.ui.write(
            f"  Auto-send   : files={self.settings.auto_send_files} "
            f"projects={self.settings.auto_send_projects} chat={self.settings.auto_send_chat}"
        )
        self.ui.write("")
        self.link_telegram()

    def cmd_status(self):
        from codex.app import render_status

        render_status(self.ui, self.settings, self.providers, self.client, None)

    @staticmethod
    def _need(arg, usage):
        if not arg:
            raise WorkspaceError(f"Usage: {usage}")
        return arg
