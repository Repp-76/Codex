from pathlib import Path

SENSITIVE_FILENAMES = {".env", "id_rsa", "id_ed25519", "credentials.json"}
SENSITIVE_EXTENSIONS = {".pem", ".key", ".pfx", ".p12"}


def mask_secret(value: str | None) -> str:
    if not value:
        return "not configured"
    if len(value) <= 4:
        return "*" * len(value)
    return "*" * (len(value) - 4) + value[-4:]


def is_sensitive_path(path) -> bool:
    p = Path(path)
    if p.name in SENSITIVE_FILENAMES:
        return True
    if p.suffix.lower() in SENSITIVE_EXTENSIONS:
        return True
    if "ssh" in p.parts:
        return True
    return False
