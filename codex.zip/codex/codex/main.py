import sys


def main():
    # Only the stdlib-only terminal module is imported before the clear, so
    # nothing else can print above the banner.
    from codex.terminal import TerminalManager

    term = TerminalManager()
    term.clear_screen()
    term.reset()

    from codex.app import run

    try:
        return run(term)
    except KeyboardInterrupt:
        sys.stdout.write("\n")
        return 130
