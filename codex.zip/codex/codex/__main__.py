from codex.main import main

raise SystemExit(main())
