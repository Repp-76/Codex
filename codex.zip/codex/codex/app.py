import sys

from codex import ai
from codex.agent import Agent
from codex.cli import Cli
from codex.config import PROVIDER_ORDER, load
from codex.conversation import Conversation
from codex.files.workspace import Workspace
from codex.security import register_secrets
from codex.telegram.client import TelegramClient
from codex.telegram.delivery import DeliveryManager
from codex.telegram.events import EventBus
from codex.terminal import quiet
from codex.ui import UI


def probe_telegram(client):
    if client is None:
        return "Not configured", "dim"
    result = client.get_me()
    if result.ok:
        return "Connected", "white"
    if result.kind in ("dns", "connection", "timeout"):
        return "Unreachable", "hot"
    if result.kind == "invalid_token":
        return "Invalid token", "hot"
    return "Error", "hot"


def render_status(ui, settings, providers, client, bot_state):
    ui.section("SYSTEM", [
        ("Terminal", "OK", "white"),
        ("Python", f"OK ({sys.version.split()[0]})", "white"),
        ("Configuration", "OK" if settings.env_files else "No .env found", "white" if settings.env_files else "hot"),
    ])
    ui.section("PROVIDERS", [
        (providers[n].label, "Configured" if providers[n].configured else "Not configured",
         "white" if providers[n].configured else "dim")
        for n in PROVIDER_ORDER
    ])
    if bot_state is None:
        bot_state = ("Configured" if client else "Not configured", "white" if client else "dim")
    ui.section("TELEGRAM", [
        ("Bot", *bot_state),
        ("User ID", *(("Configured", "white") if settings.user_id else ("Not set", "dim"))),
        ("Super Admin", *(("Configured", "white") if settings.super_admin_id else ("Not set", "dim"))),
    ])
    active = providers[settings.provider]
    ui.write(f"  Active: {ui.paint(active.label + ' / ' + active.model, 'hot')}")
    ui.write("")


def run(term):
    ui = UI(term)
    ui.banner()
    ui.basic_info()
    ui.thinking("CODEX")

    with quiet():
        try:
            import readline  # noqa: F401  (line editing for input())
        except ImportError:
            pass
        settings = load()
        register_secrets(settings.secrets())
        workspace = Workspace(settings.workspace)
        providers = {name: ai.build(name, settings) for name in PROVIDER_ORDER}
        client = TelegramClient(settings.bot_token) if settings.bot_token else None
        conversation = Conversation()
        agent = Agent(workspace, conversation)
        bot_state = probe_telegram(client)

    bus = EventBus()
    delivery = DeliveryManager(
        settings, client, lambda: [workspace.root, settings.home], ui.note, confirm=ui.confirm
    )
    bus.subscribe(delivery.handle)

    ui.done_thinking()
    render_status(ui, settings, providers, client, bot_state)
    ui.note("Type /help for commands. Start a block with \"\"\" for multiline input.")
    ui.write("")

    cli = Cli(term, ui, settings, workspace, providers, conversation, agent, delivery, bus, client)
    cli.first_run_telegram()
    return cli.loop()
