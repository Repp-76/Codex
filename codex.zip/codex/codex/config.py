import json
import os
from dataclasses import dataclass, field
from pathlib import Path

PROVIDER_ORDER = ["openai", "anthropic", "gemini", "deepseek", "openrouter"]
KEY_VARS = {
    "openai": "OPENAI_API_KEY",
    "anthropic": "ANTHROPIC_API_KEY",
    "gemini": "GEMINI_API_KEY",
    "deepseek": "DEEPSEEK_API_KEY",
    "openrouter": "OPENROUTER_API_KEY",
}


def parse_env_file(path):
    values = {}
    try:
        lines = Path(path).read_text(encoding="utf-8").splitlines()
    except OSError:
        return values
    for line in lines:
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        if line.startswith("export "):
            line = line[7:]
        key, _, value = line.partition("=")
        value = value.strip()
        if len(value) >= 2 and value[0] == value[-1] and value[0] in "\"'":
            value = value[1:-1]
        elif " #" in value:
            value = value.split(" #", 1)[0].strip()
        values[key.strip()] = value
    return values


def _flag(value, default):
    if value is None or value == "":
        return default
    return value.strip().lower() in ("1", "true", "yes", "on")


@dataclass
class Settings:
    home: Path
    workspace: Path
    bot_token: str = ""
    super_admin_id: str = ""
    user_id: str = ""
    api_keys: dict = field(default_factory=dict)
    models: dict = field(default_factory=dict)
    provider: str = "openai"
    auto_send_files: bool = True
    auto_send_projects: bool = True
    auto_send_chat: bool = False
    env_files: list = field(default_factory=list)

    @property
    def state_path(self):
        return self.home / "state.json"

    def secrets(self):
        return [self.bot_token, *self.api_keys.values()]

    def save_state(self):
        self.home.mkdir(parents=True, exist_ok=True)
        state = {"user_id": self.user_id, "provider": self.provider, "models": self.models}
        tmp = self.state_path.with_suffix(".tmp")
        tmp.write_text(json.dumps(state, indent=2), encoding="utf-8")
        try:
            os.chmod(tmp, 0o600)
        except OSError:
            pass
        os.replace(tmp, self.state_path)

    def set_user_id(self, user_id):
        self.user_id = user_id
        self.save_state()


def load(home=None, cwd=None, environ=None):
    environ = os.environ if environ is None else environ
    home = Path(home or environ.get("CODEX_HOME") or Path.home() / ".codex")
    cwd = Path(cwd or Path.cwd())

    candidates = [cwd / ".env", Path(__file__).resolve().parent.parent / ".env", home / ".env"]
    merged, used = {}, []
    for path in reversed(candidates):
        values = parse_env_file(path)
        if values:
            merged.update(values)
            used.append(path)
    for key, value in environ.items():
        if value:
            merged[key] = value

    try:
        state = json.loads((home / "state.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        state = {}
    if not isinstance(state, dict):
        state = {}

    api_keys = {name: merged.get(var, "").strip() for name, var in KEY_VARS.items()}
    models = {name: merged.get(f"{name.upper()}_MODEL", "").strip() for name in KEY_VARS}
    models.update({k: v for k, v in (state.get("models") or {}).items() if isinstance(v, str) and v})

    provider = state.get("provider")
    if provider not in KEY_VARS:
        provider = next((n for n in PROVIDER_ORDER if api_keys[n]), PROVIDER_ORDER[0])

    workspace = Path(merged.get("CODEX_WORKSPACE") or cwd / "workspace").expanduser()

    return Settings(
        home=home,
        workspace=workspace,
        bot_token=merged.get("TELEGRAM_BOT_TOKEN", "").strip(),
        super_admin_id=merged.get("TELEGRAM_SUPER_ADMIN_ID", "").strip(),
        user_id=str(state.get("user_id") or merged.get("TELEGRAM_USER_ID", "")).strip(),
        api_keys=api_keys,
        models=models,
        provider=provider,
        auto_send_files=_flag(merged.get("TELEGRAM_AUTO_SEND_FILES"), True),
        auto_send_projects=_flag(merged.get("TELEGRAM_AUTO_SEND_PROJECTS"), True),
        auto_send_chat=_flag(merged.get("TELEGRAM_AUTO_SEND_CHAT"), False),
        env_files=used,
    )
