# CODEX

Terminal AI coding assistant by Repp76. Python 3.9+, standard library only.
Providers: OpenAI, Claude, Gemini, DeepSeek, OpenRouter. Generated files and projects
are delivered to your own Telegram ID.

## Install

**Linux / macOS**

    git clone <your-repo> codex && cd codex
    cp .env.example .env        # then edit .env
    python3 -m codex

**Termux**

    pkg update && pkg install python git
    cd codex
    cp .env.example .env && nano .env
    python -m codex

**Windows**

    py -m pip install -r requirements.txt
    copy .env.example .env
    py -m codex

No other dependencies. Run it from the folder that contains the `codex/` package.

## Configure

Edit `.env` (never commit it):

    TELEGRAM_BOT_TOKEN=            # from @BotFather
    TELEGRAM_SUPER_ADMIN_ID=       # owner: receives "new user" notices only
    TELEGRAM_USER_ID=              # optional pre-fill; see below

    OPENAI_API_KEY=
    GEMINI_API_KEY=
    ANTHROPIC_API_KEY=
    DEEPSEEK_API_KEY=
    OPENROUTER_API_KEY=

    TELEGRAM_AUTO_SEND_FILES=true
    TELEGRAM_AUTO_SEND_PROJECTS=true
    TELEGRAM_AUTO_SEND_CHAT=false

Optional: `CODEX_WORKSPACE` (default `./workspace`), `CODEX_HOME` (default `~/.codex`),
and `<PROVIDER>_MODEL`, for example `OPENAI_MODEL=gpt-4.1`. Default model names are
only starting points; change them with `/model` if a provider retires one.

`TELEGRAM_USER_ID` and `TELEGRAM_SUPER_ADMIN_ID` are separate. Files always go to the
user ID. The ID you type at first run is saved in `~/.codex/state.json` and takes
precedence over `.env`. Change it with `/telegram id`.

## Telegram setup

1. Create a bot with @BotFather and put the token in `.env`.
2. Open the bot in Telegram and press **Start**. A bot cannot message someone who never started it.
3. Get your numeric ID (for example from @userinfobot).
4. Start CODEX and enter the ID at `Enter your Telegram ID:`.

## Commands

| Command | Action |
|---|---|
| `/help` `/clear` `/exit` `/status` | basics |
| `/provider [name]` `/model [name]` | show or switch (no silent fallback) |
| `/project [path]` `/files` | workspace |
| `/open` `/show` `/edit` `/fix` `/run` `/undo` | work with files |
| `/new` | fresh conversation |
| `/export [md]` `/send-chat` | sanitized transcript, optionally sent |
| `/send <file or folder>` | send manually (folders become a ZIP) |
| `/telegram [id\|test]` | status, change ID, test message |

Type a request and press Enter. Paste multi-line text directly, or wrap it in `"""` lines.
End a line with `\` to continue it.

## Safety

- Writes stay inside the workspace. `../` and outside absolute paths are rejected.
- `.env`, keys, credentials, `.git`, `node_modules`, caches are never read, written, zipped or auto-sent. File contents are scanned for API keys, tokens and private keys too. `/send` on a protected file asks for confirmation.
- Secrets are redacted from errors, exports and `/show` output.
- `/run` shows the command, asks first, refuses destructive patterns, times out at 60 s, and removes API keys and the bot token from the child's environment.
- Every overwrite is backed up under `.codex/backups`; `/undo` reverts the last batch.

## Tests

    python -m unittest discover -s tests -t .

84 tests with mocked Telegram and providers, plus a pseudo-terminal test that checks the
screen clear is the first thing written. Mocked tests do not prove real delivery; use the
manual test below.

## Manual Telegram test

1. Create the bot, put its token and your admin ID in `.env`.
2. Open the bot in Telegram, press **Start**.
3. Run `python -m codex`, enter your Telegram ID.
4. Optional check: `/telegram test` should arrive in your chat.
5. Ask: `Create test.html`
6. Confirm `workspace/test.html` exists.
7. Confirm Telegram received `test.html`.
8. Confirm the terminal printed `[TELEGRAM] SENT: test.html` only after the upload finished.
9. Turn off your connection and repeat: you should see `[TELEGRAM] FAILED` with a reason, and CODEX keeps running.

## Troubleshooting

- **Delivery unavailable / chat not found:** open the bot and press Start; check the ID.
- **Invalid token:** recheck `TELEGRAM_BOT_TOKEN`.
- **Timeout on upload:** the file may have arrived. CODEX won't resend automatically; use `/send`.
- **"API key was rejected":** wrong or expired key; check the provider's dashboard.
- **Invalid model:** `/model <name>` with a model your account can use.
- **Garbled colors:** set `NO_COLOR=1`.
