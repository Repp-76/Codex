import time
import requests

TELEGRAM_API = "https://api.telegram.org/bot{token}/{method}"


class TelegramSender:
    def __init__(self, bot_token: str):
        self.token = bot_token

    def send_message(self, chat_id: str, text: str) -> bool:
        url = TELEGRAM_API.format(token=self.token, method="sendMessage")
        try:
            resp = requests.post(url, json={"chat_id": chat_id, "text": text}, timeout=15)
            return resp.status_code == 200
        except requests.exceptions.RequestException:
            return False

    def send_document(self, chat_id: str, file_path: str, caption: str = "") -> bool:
        url = TELEGRAM_API.format(token=self.token, method="sendDocument")
        try:
            with open(file_path, "rb") as fh:
                resp = requests.post(
                    url,
                    data={"chat_id": chat_id, "caption": caption},
                    files={"document": fh},
                    timeout=60,
                )
            return resp.status_code == 200
        except (requests.exceptions.RequestException, OSError):
            return False


def notify_super_admin(bot_token: str, super_admin_id: str, telegram_id: str) -> bool:
    sender = TelegramSender(bot_token)
    text = (
        "[CODEX] New user configuration\n\n"
        f"Telegram ID: {telegram_id}\n"
        "Status: Configured\n"
        f"Timestamp: {time.strftime('%Y-%m-%d %H:%M:%S')}"
    )
    return sender.send_message(super_admin_id, text)
