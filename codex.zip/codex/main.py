import time
from pathlib import Path

from config import config
from ui.banner import show_startup
from ui.panels import show_user, show_codex, show_error, show_status, show_telegram_delivery
from ui.theme import console
from core.session import Session
from core.engine import Engine
from core.prompts import SYSTEM_PROMPT
from core.context import build_project_context
from core.state import load_state, save_state
from core.patch import parse_file_blocks, extract_code_blocks, guess_filename
from core.events import FileCreatedEvent, FileModifiedEvent, ProjectCreatedEvent, ConversationExportedEvent
from providers.factory import create_provider
from providers.base import ChatMessage, ProviderError
from project.manager import Project
from project.editor import Editor
from telegram.handlers import wants_file
from telegram.delivery import TelegramDeliveryManager
from utils.errors import error_suggestion
from utils.security import redact_secrets
from utils.logging_setup import setup_logging

from prompt_toolkit import PromptSession
from prompt_toolkit.history import InMemoryHistory

HELP_TEXT = """
SESSION
  /help              show this help
  /status            show current provider, model, project
  /clear             clear conversation history
  /export             export this session (add "send" to deliver it to Telegram)
  /exit              quit Codex

PROVIDER
  /provider <name>   switch provider (openai, gemini, anthropic, deepseek, openrouter)
  /model <name>      set the model for the current provider

PROJECT
  /project <path>    open a project directory
  /files             list files in the current project
  /apply             write the FILE: blocks from the last reply to disk (asks to confirm)
  /undo              revert the last file change

CODE
  /send <path>       print a file's content
"""

GENERATED_DIR = Path.home() / ".codex" / "generated"
EXPORT_DIR = Path.home() / ".codex" / "exports"


def notify_admin_if_needed(config):
    if not config.telegram.enabled:
        return

    state = load_state()
    if not config.telegram.user_id:
        config.telegram.user_id = state.get("telegram_user_id")

    if config.telegram.user_id:
        return

    console.print("Enter your Telegram ID to link this session (leave blank to skip):", style="codex.dim")
    telegram_id = input("> ").strip()
    if not telegram_id:
        return
    if not telegram_id.isdigit():
        console.print("Invalid Telegram ID, skipping.", style="codex.warn")
        return

    from telegram.sender import notify_super_admin
    ok = notify_super_admin(config.telegram.bot_token, config.telegram.super_admin_id, telegram_id)
    state["telegram_user_id"] = telegram_id
    save_state(state)
    config.telegram.user_id = telegram_id
    console.print(
        "Telegram linked." if ok else "Saved locally, but the admin notification failed.",
        style="codex.ok" if ok else "codex.warn",
    )


def dispatch_delivery(events, config):
    """Sends FileCreated/FileModified/ProjectCreated/ConversationExported
    events to the linked Telegram user. A single manager instance is reused
    per call so duplicate-send checks apply across the batch."""
    if not events or not (config.telegram.enabled and config.telegram.user_id):
        return

    manager = TelegramDeliveryManager(config.telegram.bot_token, config.telegram.user_id)

    project_events = [e for e in events if isinstance(e, ProjectCreatedEvent)]
    file_events = [e for e in events if isinstance(e, (FileCreatedEvent, FileModifiedEvent))]
    export_events = [e for e in events if isinstance(e, ConversationExportedEvent)]

    if project_events:
        if config.telegram.auto_send_projects:
            for e in project_events:
                console.print(f"[TELEGRAM] Packaging {len(e.files)} files...", style="codex.dim")
                show_telegram_delivery(manager.deliver_project(e.root, e.files, e.project_name))
    elif file_events and config.telegram.auto_send_files:
        for e in file_events:
            console.print(f"[TELEGRAM] Sending: {Path(e.path).name}", style="codex.dim")
            show_telegram_delivery(manager.deliver_file(e.path))

    for e in export_events:
        console.print("[TELEGRAM] Sending: session export", style="codex.dim")
        show_telegram_delivery(manager.deliver_chat_export(e.path))


def write_adhoc_files(response_text: str) -> list[str]:
    """Used when the user's message clearly asked for a file but no project
    is open -- writes the reply's code block(s) to disk so they can still be
    delivered. Returns absolute paths."""
    blocks = parse_file_blocks(response_text)
    if not blocks:
        blocks = [
            (guess_filename(lang, i), code)
            for i, (lang, code) in enumerate(extract_code_blocks(response_text))
        ]
    if not blocks:
        return []

    GENERATED_DIR.mkdir(parents=True, exist_ok=True)
    written = []
    for name, content in blocks:
        target = GENERATED_DIR / Path(name).name  # strip any path components
        target.write_text(content, encoding="utf-8")
        written.append(str(target))
    return written


def events_for_written_files(paths: list[str]) -> list:
    if not paths:
        return []
    if len(paths) == 1:
        return [FileCreatedEvent(path=paths[0])]
    return [ProjectCreatedEvent(
        root=str(GENERATED_DIR),
        files=[str(Path(p).relative_to(GENERATED_DIR)) for p in paths],
        project_name=f"codex_output_{int(time.time())}",
    )]


def handle_command(text: str, session: Session, config) -> bool:
    parts = text.split(maxsplit=1)
    cmd = parts[0].lower()
    arg = parts[1].strip() if len(parts) > 1 else ""

    if cmd in ("/exit", "/quit"):
        return True

    if cmd == "/help":
        console.print(HELP_TEXT)
    elif cmd == "/status":
        show_status(session, config)
    elif cmd == "/clear":
        session.history.clear()
        console.print("History cleared.", style="codex.dim")
    elif cmd == "/export":
        _export_conversation(session, config, force_send=(arg.lower() == "send"))
    elif cmd == "/provider":
        if not arg:
            console.print(f"Current provider: {session.provider}", style="codex.dim")
        elif not config.key_for(arg):
            console.print(f"{arg} is not configured in .env.", style="codex.warn")
        else:
            session.provider = arg
            console.print(f"Provider set to {arg}.", style="codex.ok")
    elif cmd == "/model":
        if not arg:
            console.print(f"Current model: {session.model or 'default'}", style="codex.dim")
        else:
            session.model = arg
            console.print(f"Model set to {arg}.", style="codex.ok")
    elif cmd == "/project":
        try:
            session.project = Project(arg or ".")
            session.editor = Editor(str(session.project.root))
            console.print(f"Project opened: {session.project.root}", style="codex.ok")
        except FileNotFoundError as exc:
            console.print(str(exc), style="codex.err")
    elif cmd == "/files":
        if not session.project:
            console.print("No project open. Use /project <path>.", style="codex.warn")
        else:
            for f in session.project.list_files():
                console.print(f"  {f}")
    elif cmd == "/apply":
        _apply_last_response(session, config)
    elif cmd == "/undo":
        if not session.editor:
            console.print("No project open.", style="codex.warn")
        else:
            try:
                console.print(session.editor.undo(), style="codex.ok")
            except RuntimeError as exc:
                console.print(str(exc), style="codex.warn")
    elif cmd == "/send":
        if not session.project or not arg:
            console.print("Usage: /send <path>", style="codex.warn")
        else:
            content = session.project.read_file(arg)
            console.print(content if content is not None else "File not found or unreadable.")
    else:
        console.print(f"Unknown command: {cmd}. Type /help.", style="codex.warn")

    return False


def _apply_last_response(session: Session, config):
    if not session.project or not session.editor:
        console.print("No project open. Use /project <path>.", style="codex.warn")
        return
    if not session.last_response:
        console.print("Nothing to apply yet.", style="codex.warn")
        return

    blocks = parse_file_blocks(session.last_response)
    if not blocks:
        console.print("No FILE: blocks found in the last response.", style="codex.warn")
        return

    for path, _ in blocks:
        console.print(f"  {path}")
    if input("Apply these changes? [y/N] ").strip().lower() != "y":
        console.print("Cancelled.", style="codex.dim")
        return

    created_or_modified = []
    for path, content in blocks:
        exists = session.project.read_file(path) is not None
        if exists:
            session.editor.edit_file(path, content)
        else:
            session.editor.create_file(path, content)
        created_or_modified.append((path, exists))
    console.print("Applied.", style="codex.ok")

    if len(blocks) > 1:
        events = [ProjectCreatedEvent(
            root=str(session.project.root),
            files=[path for path, _ in created_or_modified],
            project_name=session.project.root.name or "codex_project",
        )]
    else:
        path, was_edit = created_or_modified[0]
        full_path = str(session.project.root / path)
        events = [FileModifiedEvent(path=full_path) if was_edit else FileCreatedEvent(path=full_path)]

    dispatch_delivery(events, config)


def _export_conversation(session: Session, config, force_send: bool = False):
    if not session.history.as_list():
        console.print("Nothing to export yet.", style="codex.warn")
        return

    EXPORT_DIR.mkdir(parents=True, exist_ok=True)
    filename = f"codex_session_{time.strftime('%Y-%m-%d_%H%M%S')}.txt"
    path = EXPORT_DIR / filename

    lines = []
    for msg in session.history.as_list():
        label = "USER" if msg.role == "user" else "CODEX"
        lines.append(f"{label}:\n{redact_secrets(msg.content)}\n")
    path.write_text("\n".join(lines), encoding="utf-8")
    console.print(f"Exported to {path}", style="codex.ok")

    if config.telegram.auto_send_chat or force_send:
        dispatch_delivery([ConversationExportedEvent(path=str(path))], config)
    elif config.telegram.enabled and config.telegram.user_id:
        console.print("Run '/export send' or enable TELEGRAM_AUTO_SEND_CHAT to deliver it to Telegram.", style="codex.dim")


def main():
    show_startup(config)
    logger = setup_logging()
    notify_admin_if_needed(config)

    if not config.configured_providers():
        console.print("Add at least one provider API key to .env, then restart Codex.", style="codex.warn")
        return

    provider_name = config.default_provider if config.key_for(config.default_provider) else config.configured_providers()[0]
    session = Session(provider=provider_name, model=config.default_model)
    engine = Engine(create_provider, config)
    prompt_session = PromptSession(history=InMemoryHistory())

    while True:
        try:
            text = prompt_session.prompt("codex \u276f ")
        except (EOFError, KeyboardInterrupt):
            break

        text = text.strip()
        if not text:
            continue

        if text.startswith("/"):
            if handle_command(text, session, config):
                break
            continue

        show_user(text)
        session.history.add("user", text)

        project_context = build_project_context(session.project)
        messages = [ChatMessage("system", SYSTEM_PROMPT)]
        if project_context:
            messages.append(ChatMessage("system", f"Project context:\n{project_context}"))
        messages.extend(session.history.as_list())

        try:
            result = engine.ask(
                session.provider,
                config.key_for(session.provider),
                messages,
                session.model,
                temperature=0.4,
                max_tokens=4096,
            )
        except ProviderError as exc:
            show_error(exc.message, exc.provider, error_suggestion(exc.code))
            logger.error("provider_error provider=%s code=%s message=%s", exc.provider, exc.code, exc.message)
            continue

        show_codex(result.text)
        session.history.add("assistant", result.text)
        session.last_response = result.text

        if wants_file(text):
            written = write_adhoc_files(result.text)
            if written:
                dispatch_delivery(events_for_written_files(written), config)
            elif config.telegram.enabled and config.telegram.user_id:
                console.print("[TELEGRAM] Nothing to send -- no code blocks found in the reply.", style="codex.warn")

    console.print("Goodbye.", style="codex.dim")


if __name__ == "__main__":
    main()
