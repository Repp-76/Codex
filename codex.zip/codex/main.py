from config import config
from ui.banner import show_startup
from ui.panels import show_user, show_codex, show_error, show_status
from ui.theme import console
from core.session import Session
from core.engine import Engine
from core.prompts import SYSTEM_PROMPT
from core.context import build_project_context
from core.state import load_state, save_state
from core.patch import parse_file_blocks
from providers.factory import create_provider
from providers.base import ChatMessage, ProviderError
from project.manager import Project
from project.editor import Editor
from utils.errors import error_suggestion
from utils.logging_setup import setup_logging

from prompt_toolkit import PromptSession
from prompt_toolkit.history import InMemoryHistory

HELP_TEXT = """
SESSION
  /help              show this help
  /status            show current provider, model, project
  /clear             clear conversation history
  /exit              quit Codex

PROVIDER
  /provider <name>   switch provider (openai, gemini, anthropic, deepseek, openrouter)
  /model <name>      set the model for the current provider

PROJECT
  /project <path>    open a project directory
  /files             list files in the current project
  /apply             write the FILE: blocks from the last reply to disk (asks to confirm)
  /undo              revert the last file change

CODE
  /send <path>       print a file's content
"""

logger = setup_logging()


def notify_admin_if_needed():
    if not config.telegram.enabled:
        return
    state = load_state()
    if state.get("telegram_id"):
        return

    console.print("Enter your Telegram ID to link this session (leave blank to skip):", style="codex.dim")
    telegram_id = input("> ").strip()
    if not telegram_id:
        return
    if not telegram_id.isdigit():
        console.print("Invalid Telegram ID, skipping.", style="codex.warn")
        return

    from telegram.sender import notify_super_admin
    ok = notify_super_admin(config.telegram.bot_token, config.telegram.super_admin_id, telegram_id)
    state["telegram_id"] = telegram_id
    save_state(state)
    console.print(
        "Telegram linked." if ok else "Saved locally, but the admin notification failed.",
        style="codex.ok" if ok else "codex.warn",
    )


def handle_command(text: str, session: Session) -> bool:
    parts = text.split(maxsplit=1)
    cmd = parts[0].lower()
    arg = parts[1].strip() if len(parts) > 1 else ""

    if cmd in ("/exit", "/quit"):
        return True

    if cmd == "/help":
        console.print(HELP_TEXT)
    elif cmd == "/status":
        show_status(session, config)
    elif cmd == "/clear":
        session.history.clear()
        console.print("History cleared.", style="codex.dim")
    elif cmd == "/provider":
        if not arg:
            console.print(f"Current provider: {session.provider}", style="codex.dim")
        elif not config.key_for(arg):
            console.print(f"{arg} is not configured in .env.", style="codex.warn")
        else:
            session.provider = arg
            console.print(f"Provider set to {arg}.", style="codex.ok")
    elif cmd == "/model":
        if not arg:
            console.print(f"Current model: {session.model or 'default'}", style="codex.dim")
        else:
            session.model = arg
            console.print(f"Model set to {arg}.", style="codex.ok")
    elif cmd == "/project":
        try:
            session.project = Project(arg or ".")
            session.editor = Editor(str(session.project.root))
            console.print(f"Project opened: {session.project.root}", style="codex.ok")
        except FileNotFoundError as exc:
            console.print(str(exc), style="codex.err")
    elif cmd == "/files":
        if not session.project:
            console.print("No project open. Use /project <path>.", style="codex.warn")
        else:
            for f in session.project.list_files():
                console.print(f"  {f}")
    elif cmd == "/apply":
        _apply_last_response(session)
    elif cmd == "/undo":
        if not session.editor:
            console.print("No project open.", style="codex.warn")
        else:
            try:
                console.print(session.editor.undo(), style="codex.ok")
            except RuntimeError as exc:
                console.print(str(exc), style="codex.warn")
    elif cmd == "/send":
        if not session.project or not arg:
            console.print("Usage: /send <path>", style="codex.warn")
        else:
            content = session.project.read_file(arg)
            console.print(content if content is not None else "File not found or unreadable.")
    else:
        console.print(f"Unknown command: {cmd}. Type /help.", style="codex.warn")

    return False


def _apply_last_response(session: Session):
    if not session.project or not session.editor:
        console.print("No project open. Use /project <path>.", style="codex.warn")
        return
    if not session.last_response:
        console.print("Nothing to apply yet.", style="codex.warn")
        return

    blocks = parse_file_blocks(session.last_response)
    if not blocks:
        console.print("No FILE: blocks found in the last response.", style="codex.warn")
        return

    for path, _ in blocks:
        console.print(f"  {path}")
    if input("Apply these changes? [y/N] ").strip().lower() != "y":
        console.print("Cancelled.", style="codex.dim")
        return

    for path, content in blocks:
        exists = session.project.read_file(path) is not None
        if exists:
            session.editor.edit_file(path, content)
        else:
            session.editor.create_file(path, content)
    console.print("Applied.", style="codex.ok")


def main():
    show_startup(config)
    notify_admin_if_needed()

    if not config.configured_providers():
        console.print("Add at least one provider API key to .env, then restart Codex.", style="codex.warn")
        return

    provider_name = config.default_provider if config.key_for(config.default_provider) else config.configured_providers()[0]
    session = Session(provider=provider_name, model=config.default_model)
    engine = Engine(create_provider, config)
    prompt_session = PromptSession(history=InMemoryHistory())

    while True:
        try:
            text = prompt_session.prompt("codex \u276f ")
        except (EOFError, KeyboardInterrupt):
            break

        text = text.strip()
        if not text:
            continue

        if text.startswith("/"):
            if handle_command(text, session):
                break
            continue

        show_user(text)
        session.history.add("user", text)

        project_context = build_project_context(session.project)
        messages = [ChatMessage("system", SYSTEM_PROMPT)]
        if project_context:
            messages.append(ChatMessage("system", f"Project context:\n{project_context}"))
        messages.extend(session.history.as_list())

        try:
            result = engine.ask(
                session.provider,
                config.key_for(session.provider),
                messages,
                session.model,
                temperature=0.4,
                max_tokens=4096,
            )
        except ProviderError as exc:
            show_error(exc.message, exc.provider, error_suggestion(exc.code))
            logger.error("provider_error provider=%s code=%s message=%s", exc.provider, exc.code, exc.message)
            continue

        show_codex(result.text)
        session.history.add("assistant", result.text)
        session.last_response = result.text

    console.print("Goodbye.", style="codex.dim")


if __name__ == "__main__":
    main()
