import re

FILE_BLOCK_RE = re.compile(
    r"FILE:\s*(?P<path>\S+)\s*\n```[a-zA-Z0-9_+-]*\n(?P<content>.*?)\n```",
    re.DOTALL,
)


def parse_file_blocks(text: str) -> list[tuple[str, str]]:
    return [(m.group("path"), m.group("content")) for m in FILE_BLOCK_RE.finditer(text)]
