import os
from dataclasses import dataclass
from dotenv import load_dotenv

from utils.security import mask_secret

load_dotenv()

PROVIDER_KEYS = {
    "openai": "OPENAI_API_KEY",
    "gemini": "GEMINI_API_KEY",
    "anthropic": "ANTHROPIC_API_KEY",
    "deepseek": "DEEPSEEK_API_KEY",
    "openrouter": "OPENROUTER_API_KEY",
}


@dataclass
class TelegramConfig:
    bot_token: str | None
    super_admin_id: str | None  # owner/developer -- receives admin notifications
    user_id: str | None         # the linked user -- receives generated files/content
    auto_send_files: bool
    auto_send_projects: bool
    auto_send_chat: bool

    @property
    def enabled(self) -> bool:
        return bool(self.bot_token)


def _parse_bool(value: str | None, default: bool) -> bool:
    if value is None or value == "":
        return default
    return value.strip().lower() in ("1", "true", "yes", "on")


class Config:
    def __init__(self):
        self.default_provider = os.getenv("DEFAULT_PROVIDER", "openai").lower()
        self.default_model = os.getenv("DEFAULT_MODEL", "")

        # TELEGRAM_CHAT_ID is the old variable name some users may still have set;
        # TELEGRAM_USER_ID takes priority when both are present.
        user_id = os.getenv("TELEGRAM_USER_ID") or os.getenv("TELEGRAM_CHAT_ID") or None

        self.telegram = TelegramConfig(
            bot_token=os.getenv("TELEGRAM_BOT_TOKEN") or None,
            super_admin_id=os.getenv("TELEGRAM_SUPER_ADMIN_ID") or None,
            user_id=user_id,
            auto_send_files=_parse_bool(os.getenv("TELEGRAM_AUTO_SEND_FILES"), default=True),
            auto_send_projects=_parse_bool(os.getenv("TELEGRAM_AUTO_SEND_PROJECTS"), default=True),
            auto_send_chat=_parse_bool(os.getenv("TELEGRAM_AUTO_SEND_CHAT"), default=False),
        )
        self._keys = {name: os.getenv(env_var) or None for name, env_var in PROVIDER_KEYS.items()}

    def key_for(self, provider: str) -> str | None:
        return self._keys.get(provider)

    def configured_providers(self) -> list[str]:
        return [name for name, key in self._keys.items() if key]

    def status_lines(self):
        return [(name, bool(key), mask_secret(key) if key else None) for name, key in self._keys.items()]


config = Config()
