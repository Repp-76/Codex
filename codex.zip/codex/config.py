import os
from dataclasses import dataclass
from dotenv import load_dotenv

from utils.security import mask_secret

load_dotenv()

PROVIDER_KEYS = {
    "openai": "OPENAI_API_KEY",
    "gemini": "GEMINI_API_KEY",
    "anthropic": "ANTHROPIC_API_KEY",
    "deepseek": "DEEPSEEK_API_KEY",
    "openrouter": "OPENROUTER_API_KEY",
}


@dataclass
class TelegramConfig:
    bot_token: str | None
    super_admin_id: str | None

    @property
    def enabled(self) -> bool:
        return bool(self.bot_token)


class Config:
    def __init__(self):
        self.default_provider = os.getenv("DEFAULT_PROVIDER", "openai").lower()
        self.default_model = os.getenv("DEFAULT_MODEL", "")
        self.telegram = TelegramConfig(
            bot_token=os.getenv("TELEGRAM_BOT_TOKEN") or None,
            super_admin_id=os.getenv("TELEGRAM_SUPER_ADMIN_ID") or None,
        )
        self._keys = {name: os.getenv(env_var) or None for name, env_var in PROVIDER_KEYS.items()}

    def key_for(self, provider: str) -> str | None:
        return self._keys.get(provider)

    def configured_providers(self) -> list[str]:
        return [name for name, key in self._keys.items() if key]

    def status_lines(self):
        return [(name, bool(key), mask_secret(key) if key else None) for name, key in self._keys.items()]


config = Config()
