import io
import os
import select
import sys
import tempfile
import unittest
import warnings
from pathlib import Path
from unittest import mock

from codex.terminal import CLEAR_SEQUENCE, TerminalManager, quiet

ROOT = Path(__file__).resolve().parent.parent


class RecordingTTY(io.StringIO):
    def isatty(self):
        return True


class ClearTests(unittest.TestCase):
    def test_clear_writes_full_sequence_and_flushes(self):
        stream = RecordingTTY()
        term = TerminalManager(stream)
        self.assertTrue(term.clear_screen())
        self.assertEqual(stream.getvalue(), CLEAR_SEQUENCE)
        self.assertIn("\x1b[3J", CLEAR_SEQUENCE)  # scrollback
        self.assertIn("\x1b[2J", CLEAR_SEQUENCE)  # screen
        self.assertTrue(CLEAR_SEQUENCE.endswith("\x1b[H"))  # cursor home

    def test_non_tty_gets_no_escape_garbage(self):
        stream = io.StringIO()
        self.assertFalse(TerminalManager(stream).clear_screen())
        self.assertEqual(stream.getvalue(), "")

    def test_windows_without_ansi_falls_back_to_cls(self):
        term = TerminalManager(RecordingTTY())
        with mock.patch.object(term, "_enable_windows_ansi", return_value=False), mock.patch("os.system") as system:
            term.clear_screen()
        system.assert_called_once_with("cls")

    def test_quiet_swallows_prints_stderr_and_warnings(self):
        out, err = io.StringIO(), io.StringIO()
        with mock.patch.object(sys, "stdout", out), mock.patch.object(sys, "stderr", err):
            with quiet():
                print("provider chatter")
                print("telegram chatter", file=sys.stderr)
                warnings.warn("library warning")
        self.assertEqual(out.getvalue() + err.getvalue(), "")


class StartupOrderTests(unittest.TestCase):
    def run_app(self, patches=()):
        from codex.main import main

        tmp = tempfile.mkdtemp()
        stdout = RecordingTTY()
        env = {"CODEX_HOME": tmp + "/home", "CODEX_WORKSPACE": tmp + "/ws", "NO_COLOR": "1"}
        with mock.patch.dict(os.environ, env, clear=True), mock.patch.object(sys, "stdout", stdout), \
                mock.patch.object(sys, "stdin", io.StringIO("/exit\n")), mock.patch("os.getcwd", return_value=tmp):
            stack = [p for p in patches]
            for p in stack:
                p.start()
            try:
                code = main()
            finally:
                for p in stack:
                    p.stop()
        return code, stdout.getvalue()

    def test_clear_comes_before_everything(self):
        code, out = self.run_app()
        self.assertEqual(code, 0)
        self.assertTrue(out.startswith(CLEAR_SEQUENCE), repr(out[:60]))
        rest = out[len(CLEAR_SEQUENCE):]
        self.assertNotIn("\x1b[2J", rest.split("C  O  D  E  X")[0])
        for marker in ("C  O  D  E  X", "[ SYSTEM ]", "[ PROVIDERS ]", "[ TELEGRAM ]"):
            self.assertIn(marker, rest)
        self.assertLess(rest.index("C  O  D  E  X"), rest.index("[ SYSTEM ]"))
        self.assertLess(rest.index("[ SYSTEM ]"), rest.index("[ PROVIDERS ]"))
        self.assertLess(rest.index("[ PROVIDERS ]"), rest.index("[ TELEGRAM ]"))

    def test_clear_is_the_first_call_and_banner_follows(self):
        calls = []
        from codex.terminal import TerminalManager as TM
        from codex.ui import UI

        real_clear, real_banner = TM.clear_screen, UI.banner
        patches = [
            mock.patch.object(TM, "clear_screen", lambda s: (calls.append("clear"), real_clear(s))[1]),
            mock.patch.object(UI, "banner", lambda s: (calls.append("banner"), real_banner(s))[1]),
            mock.patch("codex.app.load", side_effect=lambda *a, **k: (calls.append("config"), __import__("codex.config", fromlist=["load"]).load(*a, **k))[1]),
            mock.patch("codex.app.probe_telegram", side_effect=lambda c: (calls.append("telegram"), ("Not configured", "dim"))[1]),
            mock.patch("codex.app.render_status", side_effect=lambda *a: calls.append("status")),
        ]
        self.run_app(patches)
        self.assertEqual(calls, ["clear", "banner", "config", "telegram", "status"])

    def test_initialisation_noise_never_reaches_screen(self):
        def noisy_load(*a, **k):
            print("CONFIG NOISE")
            print("CONFIG STDERR", file=sys.stderr)
            warnings.warn("CONFIG WARNING")
            from codex.config import load

            return load(*a, **k)

        def noisy_probe(client):
            print("TELEGRAM NOISE")
            return "Not configured", "dim"

        real_build = __import__("codex.ai", fromlist=["build"]).build

        def noisy_build(*a, **k):
            print("PROVIDER NOISE")
            return real_build(*a, **k)

        patches = [
            mock.patch("codex.app.load", noisy_load),
            mock.patch("codex.app.probe_telegram", noisy_probe),
            mock.patch("codex.app.ai.build", noisy_build),
        ]
        _, out = self.run_app(patches)
        for noise in ("NOISE", "STDERR", "WARNING"):
            self.assertNotIn(noise, out)


@unittest.skipUnless(os.name == "posix", "needs a pty")
class RealTerminalTests(unittest.TestCase):
    def drive(self, extra_env, keys):
        import pty

        tmp = tempfile.mkdtemp()
        env = {
            "PATH": os.environ["PATH"], "HOME": tmp, "CODEX_HOME": tmp + "/home", "CODEX_WORKSPACE": tmp + "/ws",
            "PYTHONPATH": str(ROOT), "TERM": "xterm-256color", "PYTHONWARNINGS": "default",
        }
        env.update(extra_env)
        pid, fd = pty.fork()
        if pid == 0:
            os.chdir(tmp)
            os.execve(sys.executable, [sys.executable, "-m", "codex"], env)
        chunks = []
        sent = False
        while True:
            ready, _, _ = select.select([fd], [], [], 10)
            if not ready:
                break
            try:
                data = os.read(fd, 4096)
            except OSError:
                break
            if not data:
                break
            chunks.append(data)
            if not sent:  # type-ahead is held by the tty until the app reads it
                os.write(fd, keys)
                sent = True
        try:
            os.kill(pid, 9)
        except ProcessLookupError:
            pass
        os.waitpid(pid, 0)
        os.close(fd)
        return b"".join(chunks).decode("utf-8", "replace")

    def test_screen_is_cleared_before_any_output(self):
        out = self.drive({}, b"/exit\n")
        self.assertTrue(out.startswith(CLEAR_SEQUENCE), repr(out[:80]))
        self.assertIn("C  O  D  E  X", out)

    def test_clear_first_even_with_telegram_configured(self):
        env = {"TELEGRAM_BOT_TOKEN": "123456789:AAEhBOweik6ad8LmpyzaWyTsH-0pLoQ0abc", "TELEGRAM_SUPER_ADMIN_ID": "1"}
        out = self.drive(env, b"\n/exit\n")
        self.assertTrue(out.startswith(CLEAR_SEQUENCE), repr(out[:80]))
        self.assertLess(out.index("C  O  D  E  X"), out.index("Enter your Telegram ID:"))
        self.assertNotIn("123456789:AAE", out)


if __name__ == "__main__":
    unittest.main()
