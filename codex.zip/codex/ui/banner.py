import platform
from pathlib import Path

from constants import VERSION, DEVELOPER
from .theme import console

BANNER = r"""
 ██████╗ ██████╗ ██████╗ ███████╗██╗  ██╗
██╔════╝██╔═══██╗██╔══██╗██╔════╝╚██╗██╔╝
██║     ██║   ██║██║  ██║█████╗   ╚███╔╝
██║     ██║   ██║██║  ██║██╔══╝   ██╔██╗
╚██████╗╚██████╔╝██████╔╝███████╗██╔╝ ██╗
 ╚═════╝ ╚═════╝ ╚═════╝ ╚══════╝╚═╝  ╚═╝
"""


def clear_screen():
    console.clear()


def show_startup(config):
    clear_screen()
    console.print(BANNER, style="codex.red")
    console.print("AI CODE ENGINE", style="codex.dim", justify="center")
    console.print()
    console.print(f"Developer: {DEVELOPER}", style="codex.dim")
    console.print(f"Version: {VERSION}", style="codex.dim")
    console.print(f"Python: {platform.python_version()}  |  OS: {platform.system()}", style="codex.dim")
    console.print(f"Directory: {Path.cwd()}", style="codex.dim")
    console.print()

    for name, ok, masked in config.status_lines():
        mark = "[codex.ok]\u2713[/]" if ok else "[codex.err]\u2717[/]"
        suffix = f" ({masked})" if ok else ""
        console.print(f"  {mark} {name}{suffix}")

    console.print()
    if config.telegram.enabled:
        console.print("  [codex.ok]\u2713[/] Telegram bot configured")
    else:
        console.print("  [codex.dim]\u2013[/] Telegram bot not configured")

    console.print()
    if not config.configured_providers():
        console.print("No provider configured. Add an API key to .env before chatting.", style="codex.warn")
    console.print("Type /help for commands.", style="codex.dim")
    console.print()
