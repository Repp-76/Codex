import os
import platform
import sys
from pathlib import Path

from constants import VERSION, DEVELOPER
from .theme import console

BANNER = r"""
 ██████╗ ██████╗ ██████╗ ███████╗██╗  ██╗
██╔════╝██╔═══██╗██╔══██╗██╔════╝╚██╗██╔╝
██║     ██║   ██║██║  ██║█████╗   ╚███╔╝
██║     ██║   ██║██║  ██║██╔══╝   ██╔██╗
╚██████╗╚██████╔╝██████╔╝███████╗██╔╝ ██╗
 ╚═════╝ ╚═════╝ ╚═════╝ ╚══════╝╚═╝  ╚═╝
"""


def clear_screen():
    """Clear the terminal reliably across Linux, Termux, macOS and Windows.

    Neither os.system("clear"/"cls") alone nor Rich's own Console.clear()
    is enough everywhere -- os.system does nothing when stdout isn't a
    real tty (common over Termux/SSH sessions), and a plain ANSI clear can
    leave scrollback behind on some terminals. Stacking both, then
    explicitly resetting cursor + screen + scrollback, is what actually
    makes old output disappear before the banner prints.
    """
    if platform.system() == "Windows":
        os.system("cls")
    else:
        os.system("clear")

    sys.stdout.write("\033[H\033[2J\033[3J")
    sys.stdout.flush()


def show_startup(config):
    # Nothing -- no logging, no provider checks, no Telegram init -- may
    # print anything before this call. clear_screen() must be the very
    # first visible thing that happens.
    clear_screen()

    console.print(BANNER, style="codex.red")
    console.print("AI CODE ENGINE", style="codex.dim", justify="center")
    console.print()
    console.print(f"Developer: {DEVELOPER}", style="codex.dim")
    console.print(f"Version: {VERSION}", style="codex.dim")
    console.print("Mode: AI Coding Assistant", style="codex.dim")
    console.print()

    console.print("[ SYSTEM ]", style="codex.red")
    console.print(f"  Python: {platform.python_version()} OK", style="codex.dim")
    console.print(f"  OS: {platform.system()}", style="codex.dim")
    console.print(f"  Directory: {Path.cwd()}", style="codex.dim")
    console.print()

    console.print("[ PROVIDERS ]", style="codex.red")
    for name, ok, masked in config.status_lines():
        status = "[codex.ok]Configured[/]" if ok else "[codex.err]Not configured[/]"
        suffix = f" ({masked})" if ok else ""
        console.print(f"  {name}: {status}{suffix}")
    console.print()

    console.print("[ TELEGRAM ]", style="codex.red")
    if config.telegram.enabled:
        console.print("  Bot: [codex.ok]Connected[/]")
        user_status = "[codex.ok]Configured[/]" if config.telegram.user_id else "[codex.dim]Not linked yet[/]"
        admin_status = "[codex.ok]Configured[/]" if config.telegram.super_admin_id else "[codex.dim]Not configured[/]"
        console.print(f"  User ID: {user_status}")
        console.print(f"  Super Admin: {admin_status}")
    else:
        console.print("  Bot: [codex.dim]Not configured[/]")
    console.print()

    if not config.configured_providers():
        console.print("No provider configured. Add an API key to .env before chatting.", style="codex.warn")
    console.print("Type /help for commands.", style="codex.dim")
    console.print()
