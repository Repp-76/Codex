from rich.panel import Panel
from rich.markdown import Markdown

from .theme import console


def show_user(text: str):
    console.print(Panel(text, title="USER", border_style="white", title_align="left"))


def show_codex(text: str):
    console.print(Panel(Markdown(text), title="CODEX", border_style="red", title_align="left"))


def show_error(message: str, provider: str = "", suggestion: str = ""):
    body = message
    if suggestion:
        body += f"\n\nSuggested action: {suggestion}"
    console.print(Panel(body, title="CODEX ERROR", border_style="bold red"))


def show_status(session, config):
    project_name = session.project.root.name if session.project else "none"
    console.print(
        f"[codex.red]CODEX[/]  |  {session.provider.upper()}  |  {session.model or 'default'}  |  "
        f"PROJECT: {project_name}  |  READY"
    )
